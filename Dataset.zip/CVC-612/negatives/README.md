# Hard-Negative Images — Folder Structure

Place NON-POLYP colonoscopy images here to teach the model the difference
between polyps and other abnormal-looking regions.

## Required Folder Structure

```
negatives/
├── tumor/               ← Colorectal tumors / masses (not classified by visual appearance alone)
├── inflammatory/        ← Inflammatory bowel disease, colitis, ulcers
├── normal_variants/     ← Normal mucosal folds, haustra, vascular patterns
├── artifacts/           ← Blood, bubbles, stool, debris, specular highlights
└── mined/               ← Auto-populated by hard_negative_mining.py
    └── visualisations/  ← Grad-CAM overlays for each mined false positive
```

> ⚠ IMPORTANT: Do NOT label a lesion as "cancer" or "tumor" based solely on its
> visual appearance. These images are used to teach the model that visually
> abnormal regions are NOT automatically polyps. Clinical ground truth should
> be used for labelling when available.

## Recommended Public Datasets for Negative Images

| Dataset | Description | URL |
|---|---|---|
| HyperKvasir | Large GI image dataset including non-polyp classes | https://datasets.simula.no/hyper-kvasir/ |
| ETIS-Larib | Additional colonoscopy images | https://polyp.grand-challenge.org/EtisLarib/ |
| Kvasir-SEG | Segmentation dataset with non-polyp regions | https://datasets.simula.no/kvasir-seg/ |
| CVC-ColonDB | Colonoscopy database | https://polyp.grand-challenge.org/CVCColonDB/ |

### HyperKvasir Classes Useful as Negatives

From HyperKvasir, the following classes can be used as non-polyp examples:
- `normal-cecum`
- `normal-pylorus`
- `normal-z-line`
- `esophagitis`
- `hemorrhoids`
- `retroflex-stomach`
- `ulcerative-colitis`
- `bbps-0-1`, `bbps-2-3` (bowel preparation quality images)

## How to Use

1. Download images from the datasets above
2. Place them in the appropriate sub-folder (e.g., `normal_variants/`, `inflammatory/`)
3. Run training: `python train.py`
4. Run mining to find remaining false positives: `python hard_negative_mining.py --neg_dir CVC-612/negatives`
5. After mining, retrain again with mined hard negatives included

## Current Status

| Folder | Images |
|---|---|
| `tumor/`           | 0 — Add images here |
| `inflammatory/`    | 0 — Add images here |
| `normal_variants/` | 0 — Add images here |
| `artifacts/`       | 0 — Add images here |
| `mined/`           | Auto-populated — run hard_negative_mining.py |
