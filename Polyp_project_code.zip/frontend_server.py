"""
Frontend Server - Serves the public/ folder on port 3000
Proxies /api/* requests to the Flask backend on port 5000

Built-in /api/health: probes Flask and returns its real status
so the browser always gets a 200 with JSON (never a 502 timeout).
"""
import http.server
import urllib.request
import urllib.error
import os
import json
import threading

PORT = 3000
PUBLIC_DIR = os.path.join(os.path.dirname(__file__), 'public')
FLASK_API = 'http://localhost:5000'

# Cache Flask status so health checks are instant
_flask_status = {'ok': False, 'message': 'Checking...'}
_flask_lock = threading.Lock()

def _probe_flask():
    """Background thread: probe Flask every 3 seconds and cache result."""
    import time
    while True:
        try:
            req = urllib.request.Request(
                f'{FLASK_API}/api/health',
                headers={'Connection': 'close'},
                method='GET'
            )
            with urllib.request.urlopen(req, timeout=4) as resp:
                if resp.status == 200:
                    with _flask_lock:
                        _flask_status['ok'] = True
                        _flask_status['message'] = 'Flask server is running'
                else:
                    with _flask_lock:
                        _flask_status['ok'] = False
                        _flask_status['message'] = f'Flask returned {resp.status}'
        except Exception as e:
            with _flask_lock:
                _flask_status['ok'] = False
                _flask_status['message'] = f'Flask unreachable: {type(e).__name__}'
        time.sleep(3)


class FrontendHandler(http.server.SimpleHTTPRequestHandler):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=PUBLIC_DIR, **kwargs)

    # ------------------------------------------------------------------ #
    #  Route: GET
    # ------------------------------------------------------------------ #
    def do_GET(self):
        if self.path == '/api/health' or self.path == '/api/health/':
            # Serve our own cached health — always returns 200 with JSON
            self._send_health()
        elif self.path.startswith('/api/'):
            self._proxy_to_flask('GET')
        else:
            super().do_GET()

    # ------------------------------------------------------------------ #
    #  Route: POST
    # ------------------------------------------------------------------ #
    def do_POST(self):
        if self.path.startswith('/api/'):
            self._proxy_to_flask('POST')
        else:
            self.send_error(405, 'Method Not Allowed')

    # ------------------------------------------------------------------ #
    #  Route: OPTIONS  (CORS preflight)
    # ------------------------------------------------------------------ #
    def do_OPTIONS(self):
        self.send_response(200)
        self._cors_headers()
        self.end_headers()

    # ------------------------------------------------------------------ #
    #  Built-in health endpoint
    # ------------------------------------------------------------------ #
    def _send_health(self):
        with _flask_lock:
            ok  = _flask_status['ok']
            msg = _flask_status['message']

        payload = json.dumps({
            'status':  'ok' if ok else 'error',
            'flask':   ok,
            'message': msg
        }).encode()

        # Always 200 so fetch() never throws, JS reads flask:true/false
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(payload)))
        self._cors_headers()
        self.end_headers()
        self.wfile.write(payload)

    # ------------------------------------------------------------------ #
    #  Generic proxy
    # ------------------------------------------------------------------ #
    def _proxy_to_flask(self, method):
        target_url = FLASK_API + self.path
        try:
            headers = {}
            body = None
            if method == 'POST':
                content_length = int(self.headers.get('Content-Length', 0))
                content_type   = self.headers.get('Content-Type', '')
                body = self.rfile.read(content_length) if content_length else None
                headers['Content-Type'] = content_type

            req = urllib.request.Request(
                target_url, data=body, headers=headers, method=method
            )
            with urllib.request.urlopen(req, timeout=120) as resp:
                data = resp.read()
                self.send_response(resp.status)
                SKIP = {'transfer-encoding', 'connection', 'server',
                        'date', 'access-control-allow-origin'}
                for k, v in resp.headers.items():
                    if k.lower() not in SKIP:
                        self.send_header(k, v)
                self._cors_headers()
                self.end_headers()
                self.wfile.write(data)

        except urllib.error.HTTPError as e:
            data = e.read()
            self.send_response(e.code)
            self.send_header('Content-Type', 'application/json')
            self._cors_headers()
            self.end_headers()
            self.wfile.write(data)

        except Exception as ex:
            err = json.dumps({'error': str(ex)}).encode()
            self.send_response(502)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(err)))
            self._cors_headers()
            self.end_headers()
            self.wfile.write(err)

    # ------------------------------------------------------------------ #
    #  Helpers
    # ------------------------------------------------------------------ #
    def _cors_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')

    def log_message(self, fmt, *args):
        print(f'[Frontend] {self.address_string()} - {fmt % args}')


# ------------------------------------------------------------------ #
#  Entry point
# ------------------------------------------------------------------ #
if __name__ == '__main__':
    # Start background Flask prober
    t = threading.Thread(target=_probe_flask, daemon=True)
    t.start()

    os.chdir(PUBLIC_DIR)
    with http.server.ThreadingHTTPServer(('0.0.0.0', PORT), FrontendHandler) as httpd:
        print('=' * 55)
        print(f'  Frontend Server running on http://localhost:{PORT}')
        print(f'  Proxying /api/* --> Flask backend at {FLASK_API}')
        print('  Press Ctrl+C to stop')
        print('=' * 55)
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print('\nFrontend server stopped.')
