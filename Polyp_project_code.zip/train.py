
import os
import numpy as np
import cv2
from glob import glob
import tensorflow as tf
from tensorflow.keras.callbacks import (
    EarlyStopping, ModelCheckpoint, ReduceLROnPlateau, CSVLogger, TensorBoard
)
from data import load_data, load_data_with_negatives, tf_dataset
from model import build_model

# ============================================================
# Metrics
# ============================================================
def iou(y_true, y_pred):
    """Intersection-over-Union metric (numpy function wrapper)."""
    def f(y_true, y_pred):
        intersection = (y_true * y_pred).sum()
        union = y_true.sum() + y_pred.sum() - intersection
        x = (intersection + 1e-15) / (union + 1e-15)
        return x.astype(np.float32)
    return tf.numpy_function(f, [y_true, y_pred], tf.float32)

def dice_coeff(y_true, y_pred):
    """Sørensen–Dice coefficient metric."""
    def f(y_true, y_pred):
        intersection = (y_true * y_pred).sum()
        x = (2.0 * intersection + 1e-15) / (y_true.sum() + y_pred.sum() + 1e-15)
        return x.astype(np.float32)
    return tf.numpy_function(f, [y_true, y_pred], tf.float32)

# ============================================================
# Combined Dice + BCE loss
# ============================================================
def dice_bce_loss(y_true, y_pred):
    """
    Combined loss: Binary Cross-Entropy + Dice loss.

    BCE is good at pixel-level calibration; Dice directly optimises
    the overlap metric and handles class imbalance better than BCE alone.
    """
    # Binary cross-entropy
    bce = tf.keras.losses.binary_crossentropy(y_true, y_pred)
    bce = tf.reduce_mean(bce)

    # Dice loss
    y_true_f = tf.cast(tf.reshape(y_true, [-1]), tf.float32)
    y_pred_f = tf.reshape(y_pred, [-1])
    intersection = tf.reduce_sum(y_true_f * y_pred_f)
    dice = 1.0 - (2.0 * intersection + 1e-15) / (
        tf.reduce_sum(y_true_f) + tf.reduce_sum(y_pred_f) + 1e-15
    )
    return bce + dice

# ============================================================
# Class weighting (positive vs negative pixels)
# ============================================================
def compute_class_weight(mask_paths, neg_ratio=0.5):
    """
    Compute pixel-level class weights to handle foreground/background
    imbalance, accounting for added negative (all-zero mask) images.

    Returns:
        {0: weight_background, 1: weight_foreground}
    """
    pos_pixels = 0
    neg_pixels = 0
    for p in mask_paths:
        if not p:
            neg_pixels += 256 * 256
            continue
        mask = cv2.imread(p, cv2.IMREAD_GRAYSCALE)
        if mask is None:
            continue
        pos_pixels += np.count_nonzero(mask)
        neg_pixels += mask.size - np.count_nonzero(mask)

    total = pos_pixels + neg_pixels + 1e-9
    w_pos = total / (2.0 * pos_pixels + 1e-9)
    w_neg = total / (2.0 * neg_pixels + 1e-9)
    print(f"[Weights] Background: {w_neg:.4f}  Foreground (polyp): {w_pos:.4f}")
    return {0: float(w_neg), 1: float(w_pos)}

# ============================================================
# Main training script
# ============================================================
if __name__ == "__main__":
    # ----------------------------------------------------------
    # Configuration
    # ----------------------------------------------------------
    POLYP_PATH  = "CVC-612/"
    NEG_DIR     = "CVC-612/negatives/"   # Place hard-negative images here
    BATCH       = 8
    LR          = 1e-4
    EPOCHS      = 50
    SPLIT       = 0.1

    os.makedirs("files", exist_ok=True)

    # ----------------------------------------------------------
    # Dataset loading
    # ----------------------------------------------------------
    use_negatives = os.path.isdir(NEG_DIR) and len(
        glob(os.path.join(NEG_DIR, "**", "*.jpg"), recursive=True) +
        glob(os.path.join(NEG_DIR, "**", "*.png"), recursive=True)
    ) > 0

    if use_negatives:
        print("[Train] Loading polyp + hard-negative images...")
        (train_x, train_y, _), (valid_x, valid_y, _), (test_x, test_y, _) = \
            load_data_with_negatives(POLYP_PATH, NEG_DIR, split=SPLIT)
    else:
        print("[Train] No negatives found — training on polyp data only.")
        print(f"[Train] Add hard-negative images to: {NEG_DIR}")
        (train_x, train_y), (valid_x, valid_y), (test_x, test_y) = \
            load_data(POLYP_PATH, split=SPLIT)

    print(f"[Train] Train: {len(train_x)}  Valid: {len(valid_x)}  Test: {len(test_x)}")

    # ----------------------------------------------------------
    # Class weights
    # ----------------------------------------------------------
    class_weights = compute_class_weight(train_y)

    # ----------------------------------------------------------
    # TF Datasets  (augmentation only on training)
    # ----------------------------------------------------------
    train_dataset = tf_dataset(train_x, train_y, batch=BATCH, augment=True,  shuffle=True)
    valid_dataset = tf_dataset(valid_x, valid_y, batch=BATCH, augment=False, shuffle=False)

    train_steps = (len(train_x) + BATCH - 1) // BATCH
    valid_steps = (len(valid_x) + BATCH - 1) // BATCH

    # ----------------------------------------------------------
    # Model
    # ----------------------------------------------------------
    model = build_model()
    model.summary()

    opt = tf.keras.optimizers.Adam(LR)
    metrics = [
        "accuracy",
        tf.keras.metrics.Recall(name="recall"),
        tf.keras.metrics.Precision(name="precision"),
        iou,
        dice_coeff,
    ]
    model.compile(loss=dice_bce_loss, optimizer=opt, metrics=metrics)

    # ----------------------------------------------------------
    # Callbacks
    # ----------------------------------------------------------
    callbacks = [
        ModelCheckpoint(
            "files/model.h5",
            monitor="val_loss",
            save_best_only=True,
            verbose=1,
        ),
        ReduceLROnPlateau(
            monitor="val_loss",
            factor=0.1,
            patience=5,
            min_lr=1e-7,
            verbose=1,
        ),
        EarlyStopping(
            monitor="val_loss",
            patience=12,
            restore_best_weights=True,
            verbose=1,
        ),
        CSVLogger("files/training_log.csv", append=False),
        TensorBoard(log_dir="files/logs"),
    ]

    # ----------------------------------------------------------
    # Training
    # ----------------------------------------------------------
    history = model.fit(
        train_dataset,
        validation_data=valid_dataset,
        epochs=EPOCHS,
        steps_per_epoch=train_steps,
        validation_steps=valid_steps,
        callbacks=callbacks,
        class_weight=class_weights,
    )

    print("\n[Train] Training complete. Best model saved to files/model.h5")
    print("[Train] Run `python evaluate.py` to generate full evaluation report.")
    print("[Train] Run `python threshold_calibration.py` to calibrate thresholds.")
    print("[Train] Run `python hard_negative_mining.py` to mine hard negatives.")
