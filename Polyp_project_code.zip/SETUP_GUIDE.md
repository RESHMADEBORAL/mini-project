# Polyp Detection and Segmentation System - Setup Guide

This guide will help you set up and run the complete polyp detection and segmentation application with both frontend and backend.

## Prerequisites

1. **Python 3.8+** - for Flask backend
2. **Node.js 14+ and npm** - for Node.js frontend server
3. **Pre-trained Model** - `files/model.h5` (should already exist in the project)

## Project Structure

```
.
├── flask_app.py              # Flask API backend
├── server.js                 # Node.js/Express frontend server
├── public/
│   ├── index.html           # Main HTML interface
│   ├── styles.css           # CSS styling
│   └── script.js            # Frontend JavaScript
├── requirements.txt          # Python dependencies
├── package.json             # Node.js dependencies
└── uploads/                 # Directory for uploaded images (auto-created)
```

## Setup Instructions

### Step 1: Install Python Dependencies

```bash
# Navigate to the project directory
cd "Polyp-Segmentation-using-UNET-in-TensorFlow-2.0-master"

# Install required Python packages
pip install -r requirements.txt
```

### Step 2: Install Node.js Dependencies

```bash
# Install Node.js packages
npm install
```

### Step 3: Verify Model File

Make sure the pre-trained model exists:
- Check that `files/model.h5` is present in the project directory
- The model should be ~15-20MB in size

## Running the Application

### Option A: Run Both Servers (Recommended)

#### Terminal 1: Start Flask Backend API (Port 5000)

```bash
python flask_app.py
```

You should see:
```
Loading model...
Model loaded successfully!
 * Running on http://localhost:5000
```

#### Terminal 2: Start Node.js Frontend Server (Port 3000)

```bash
npm start
```

or

```bash
node server.js
```

You should see:
```
Node.js server running on http://localhost:3000
Flask API expected at http://localhost:5000
```

### Step 4: Open in Browser

1. Open your web browser
2. Navigate to: **http://localhost:3000**
3. You should see the "Polyp Detection & Segmentation System" interface

## Usage Guide

1. **Upload Image**: 
   - Click on the upload area or browse to select a medical image
   - Supported formats: PNG, JPG, JPEG
   - Maximum file size: 10MB

2. **View Results**:
   - Original Image: Your uploaded image
   - Segmentation Mask: Binary mask showing detected polyp regions
   - Overlay: Your image with the detected polyp area highlighted in red

3. **Statistics**:
   - Detection Percentage: Percentage of image containing polyp
   - Detected Pixels: Total number of pixels detected as polyp
   - Image Dimensions: Resolution of your image

4. **Download Results**:
   - Click "Download Results" to save the analysis as an image
   - Click "Analyze Another Image" to process a new image

## API Endpoints

The Flask backend provides the following endpoints:

### 1. Predict Endpoint
**POST** `/api/predict`

Upload an image and get segmentation results.

**Request**:
- Content-Type: `multipart/form-data`
- Parameter: `image` (file)

**Response**:
```json
{
  "success": true,
  "original_image": "base64_encoded_image",
  "segmentation_mask": "base64_encoded_mask",
  "overlay_image": "base64_encoded_overlay",
  "statistics": {
    "detected_area_pixels": 12345,
    "total_pixels": 262144,
    "detection_percentage": 4.71,
    "original_dimensions": {
      "width": 512,
      "height": 512
    }
  },
  "filename": "image.jpg"
}
```

### 2. Health Check Endpoint
**GET** `/api/health`

Check if the Flask server and model are running.

**Response**:
```json
{
  "status": "ok",
  "model": "loaded"
}
```

### 3. Model Info Endpoint
**GET** `/api/model-info`

Get information about the loaded model.

**Response**:
```json
{
  "input_shape": "(None, 256, 256, 3)",
  "output_shape": "(None, 256, 256, 1)",
  "parameters": 7759521
}
```

## Troubleshooting

### Issue: "Flask Server Disconnected"
- Make sure Flask server is running on port 5000
- Check that Python dependencies are installed
- Verify the model file exists at `files/model.h5`

### Issue: CORS Errors
- Flask-CORS is already configured in flask_app.py
- Make sure to access the frontend from http://localhost:3000

### Issue: Port Already in Use
- Port 3000 (Node.js):
  ```bash
  # Find and kill process on port 3000
  # On Windows:
  netstat -ano | findstr :3000
  taskkill /PID <PID> /F
  ```

- Port 5000 (Flask):
  ```bash
  # On Windows:
  netstat -ano | findstr :5000
  taskkill /PID <PID> /F
  ```

### Issue: Model Loading Error
- Ensure TensorFlow is properly installed: `pip install tensorflow==2.13.0`
- Check that CUDA/cuDNN are installed if using GPU
- Verify model.h5 file integrity

## Performance Tips

1. **GPU Acceleration**: If you have NVIDIA GPU:
   ```bash
   pip install tensorflow-gpu==2.13.0
   ```

2. **Batch Processing**: Modify Flask app to process multiple images

3. **Caching**: Results are cached during the session

## Configuration

### Change Ports

**Flask (flask_app.py)**:
```python
app.run(debug=True, host='0.0.0.0', port=5000)  # Change 5000 to your port
```

**Node.js (server.js)**:
```javascript
const PORT = 3000;  // Change 3000 to your port
```

Also update `FLASK_API_URL` in `public/script.js` if changing Flask port.

## Model Information

- **Architecture**: U-NET
- **Framework**: TensorFlow 2.0
- **Input Size**: 256x256 pixels (RGB)
- **Output**: Binary segmentation mask
- **Training Dataset**: CVC-612 polyp dataset

## License

This project is based on the Polyp Segmentation using U-NET in TensorFlow 2.0 implementation.

## Support

For issues or questions, check:
1. Console errors in browser DevTools (F12)
2. Flask server terminal for backend errors
3. Node.js server terminal for frontend errors

## Security Notes

- This application processes medical images - handle patient data responsibly
- For production use, implement proper authentication and encryption
- Always validate user input on both client and server
- Store patient data securely and in compliance with healthcare regulations

## Next Steps

1. Test with sample images
2. Integrate with existing medical imaging systems
3. Customize UI for your specific needs
4. Deploy to production server
5. Add patient identification and report generation features
