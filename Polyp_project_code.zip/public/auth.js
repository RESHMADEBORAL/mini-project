/* =====================================================
   AUTH.JS — PolySense Authentication Logic
   - localStorage-based user store
   - Tab switching
   - Form validation
   - Password strength
   - Toast notifications
   - Terms modal
   - Guard: redirect if already logged in
   ===================================================== */

'use strict';

// -------------------------------------------------------
// Constants
// -------------------------------------------------------
const USERS_KEY   = 'polysense_users';
const SESSION_KEY = 'polysense_session';
const REDIR_URL   = 'index.html';

// -------------------------------------------------------
// Storage helpers
// -------------------------------------------------------
function getUsers() {
    try { return JSON.parse(localStorage.getItem(USERS_KEY)) || []; }
    catch { return []; }
}

function saveUsers(users) {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function setSession(user, persist) {
    const store = persist ? localStorage : sessionStorage;
    store.setItem(SESSION_KEY, JSON.stringify({
        email:     user.email,
        firstName: user.firstName,
        lastName:  user.lastName,
        role:      user.role,
        loginAt:   Date.now()
    }));
}

function getSession() {
    return JSON.parse(localStorage.getItem(SESSION_KEY) || sessionStorage.getItem(SESSION_KEY) || 'null');
}

// -------------------------------------------------------
// Guard — already logged in → go to dashboard
// -------------------------------------------------------
(function guardAlreadyLoggedIn() {
    if (getSession()) {
        window.location.replace(REDIR_URL);
    }
})();

// -------------------------------------------------------
// Toast
// -------------------------------------------------------
let _toastTimer = null;

function toast(msg, type = 'info', duration = 3500) {
    const el   = document.getElementById('authToast');
    const icon = document.getElementById('toastIcon');
    const txt  = document.getElementById('toastMsg');

    const icons = {
        success: '✅',
        error:   '❌',
        info:    'ℹ️',
        warning: '⚠️'
    };

    icon.textContent = icons[type] || icons.info;
    txt.textContent  = msg;
    el.className     = `toast toast-${type} show`;

    if (_toastTimer) clearTimeout(_toastTimer);
    _toastTimer = setTimeout(() => el.classList.remove('show'), duration);
}

// -------------------------------------------------------
// Tab switching
// -------------------------------------------------------
function switchTab(tab) {
    const loginForm  = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    const tabLogin   = document.getElementById('tabLogin');
    const tabSignup  = document.getElementById('tabSignup');
    const indicator  = document.getElementById('tabIndicator');

    if (tab === 'login') {
        loginForm.classList.add('active');
        signupForm.classList.remove('active');
        tabLogin.classList.add('active');
        tabSignup.classList.remove('active');
        tabLogin.setAttribute('aria-selected', 'true');
        tabSignup.setAttribute('aria-selected', 'false');
        indicator.classList.remove('right');
        clearFormErrors();
    } else {
        signupForm.classList.add('active');
        loginForm.classList.remove('active');
        tabSignup.classList.add('active');
        tabLogin.classList.remove('active');
        tabSignup.setAttribute('aria-selected', 'true');
        tabLogin.setAttribute('aria-selected', 'false');
        indicator.classList.add('right');
        clearFormErrors();
    }
}

// -------------------------------------------------------
// Validation helpers
// -------------------------------------------------------
function setFieldError(groupId, errId, msg) {
    const group = document.getElementById(groupId);
    const err   = document.getElementById(errId);
    if (group) group.classList.add('has-error');
    if (err)   err.textContent = msg ? ('⚠ ' + msg) : '';
}

function clearFieldError(groupId, errId) {
    const group = document.getElementById(groupId);
    const err   = document.getElementById(errId);
    if (group) group.classList.remove('has-error');
    if (err)   err.textContent = '';
}

function clearFormErrors() {
    document.querySelectorAll('.form-group').forEach(g => g.classList.remove('has-error'));
    document.querySelectorAll('.field-error').forEach(e => e.textContent = '');
}

function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim());
}

// -------------------------------------------------------
// Password strength
// -------------------------------------------------------
const strengthLabels = ['Too weak', 'Weak', 'Fair', 'Good', 'Strong'];
const strengthColors = ['weak', 'weak', 'fair', 'good', 'strong'];

function calcStrength(pw) {
    let score = 0;
    if (pw.length >= 8)  score++;
    if (pw.length >= 12) score++;
    if (/[A-Z]/.test(pw)) score++;
    if (/[0-9]/.test(pw)) score++;
    if (/[^A-Za-z0-9]/.test(pw)) score++;
    return Math.min(score, 4);
}

function updateStrength(pw) {
    const score   = pw.length === 0 ? -1 : calcStrength(pw);
    const bars    = document.querySelectorAll('.s-bar');
    const label   = document.getElementById('strengthLabel');

    bars.forEach((b, i) => {
        b.className = 's-bar';
        if (score >= 0 && i <= score) b.classList.add(strengthColors[score]);
    });

    label.textContent = pw.length === 0
        ? 'Enter a password'
        : strengthLabels[score] || 'Strong';
    label.style.color = score < 2 ? '#f87171' : score < 3 ? '#fbbf24' : '#34d399';
}

// -------------------------------------------------------
// Toggle password visibility
// -------------------------------------------------------
function togglePass(inputId, btnId) {
    const input = document.getElementById(inputId);
    const btn   = document.getElementById(btnId);
    if (!input) return;

    const isText = input.type === 'text';
    input.type = isText ? 'password' : 'text';

    btn.innerHTML = isText
        ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`
        : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`;
}

// -------------------------------------------------------
// Terms modal
// -------------------------------------------------------
function showTerms() {
    document.getElementById('termsModal').classList.remove('hidden');
}

function closeTerms() {
    document.getElementById('termsModal').classList.add('hidden');
}

function acceptTerms() {
    const checkbox = document.getElementById('agreeTerms');
    if (checkbox) checkbox.checked = true;
    clearFieldError('sg-terms-group', 'sg-terms-err');
    closeTerms();
    toast('Terms accepted!', 'success', 2000);
}

// Close modal on overlay click
document.getElementById('termsModal').addEventListener('click', function(e) {
    if (e.target === this) closeTerms();
});

// -------------------------------------------------------
// Forgot password
// -------------------------------------------------------
function handleForgot() {
    const email = document.getElementById('loginEmail').value.trim();
    if (!email || !isValidEmail(email)) {
        toast('Enter your email address above first.', 'warning', 3000);
        document.getElementById('loginEmail').focus();
        return;
    }
    const users = getUsers();
    const found = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (found) {
        toast(`Hint: your password is saved in your browser's localStorage under "polysense_users". This is a demo system — no real email reset available.`, 'info', 6000);
    } else {
        toast('No account found for that email. Please sign up.', 'error', 3500);
    }
}

// -------------------------------------------------------
// Button loading state
// -------------------------------------------------------
function setLoading(btnId, loadingId, arrowId, on) {
    const btn  = document.getElementById(btnId);
    const load = btn.querySelector('.btn-loader');
    const txt  = btn.querySelector('.btn-text');
    const arrow = btn.querySelector('.btn-arrow');

    if (on) {
        btn.classList.add('loading');
        if (load)  load.classList.remove('hidden');
        if (txt)   txt.style.opacity = '0.5';
        if (arrow) arrow.style.display = 'none';
    } else {
        btn.classList.remove('loading');
        if (load)  load.classList.add('hidden');
        if (txt)   txt.style.opacity = '1';
        if (arrow) arrow.style.display = '';
    }
}

// -------------------------------------------------------
// LOGIN FORM
// -------------------------------------------------------
document.getElementById('loginForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    clearFormErrors();

    const email    = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value;
    const remember = document.getElementById('rememberMe').checked;

    let valid = true;

    if (!email) {
        setFieldError('lg-email-group', 'lg-email-err', 'Email is required.');
        valid = false;
    } else if (!isValidEmail(email)) {
        setFieldError('lg-email-group', 'lg-email-err', 'Enter a valid email address.');
        valid = false;
    }

    if (!password) {
        setFieldError('lg-pass-group', 'lg-pass-err', 'Password is required.');
        valid = false;
    }

    if (!valid) return;

    setLoading('loginBtn', null, null, true);

    // Simulate network latency
    await new Promise(r => setTimeout(r, 900));

    const users = getUsers();
    const user  = users.find(u =>
        u.email.toLowerCase() === email.toLowerCase() &&
        u.password === btoa(password)   // simple base64 encoding (demo only)
    );

    if (!user) {
        setLoading('loginBtn', null, null, false);
        setFieldError('lg-pass-group', 'lg-pass-err', 'Incorrect email or password.');
        toast('Login failed. Check your credentials.', 'error');
        return;
    }

    setSession(user, remember);
    toast(`Welcome back, ${user.firstName}! Redirecting...`, 'success', 2500);

    setTimeout(() => {
        window.location.href = REDIR_URL;
    }, 1200);
});

// -------------------------------------------------------
// SIGNUP FORM
// -------------------------------------------------------
document.getElementById('signupPassword').addEventListener('input', function() {
    updateStrength(this.value);
});

document.getElementById('signupForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    clearFormErrors();

    const firstName = document.getElementById('signupFirstName').value.trim();
    const lastName  = document.getElementById('signupLastName').value.trim();
    const email     = document.getElementById('signupEmail').value.trim();
    const role      = document.getElementById('signupRole').value;
    const password  = document.getElementById('signupPassword').value;
    const confirm   = document.getElementById('signupConfirm').value;
    const agreed    = document.getElementById('agreeTerms').checked;

    let valid = true;

    if (!firstName) {
        setFieldError('sg-fn-group', 'sg-fn-err', 'First name is required.');
        valid = false;
    }

    if (!lastName) {
        setFieldError('sg-ln-group', 'sg-ln-err', 'Last name is required.');
        valid = false;
    }

    if (!email) {
        setFieldError('sg-email-group', 'sg-email-err', 'Email is required.');
        valid = false;
    } else if (!isValidEmail(email)) {
        setFieldError('sg-email-group', 'sg-email-err', 'Enter a valid email address.');
        valid = false;
    }

    if (!role) {
        setFieldError('sg-role-group', 'sg-role-err', 'Please select your role.');
        valid = false;
    }

    if (!password) {
        setFieldError('sg-pass-group', 'sg-pass-err', 'Password is required.');
        valid = false;
    } else if (password.length < 8) {
        setFieldError('sg-pass-group', 'sg-pass-err', 'Password must be at least 8 characters.');
        valid = false;
    } else if (calcStrength(password) < 2) {
        setFieldError('sg-pass-group', 'sg-pass-err', 'Please use a stronger password.');
        valid = false;
    }

    if (!confirm) {
        setFieldError('sg-conf-group', 'sg-conf-err', 'Please confirm your password.');
        valid = false;
    } else if (password !== confirm) {
        setFieldError('sg-conf-group', 'sg-conf-err', 'Passwords do not match.');
        valid = false;
    }

    if (!agreed) {
        document.getElementById('sg-terms-err').textContent = '⚠ You must accept the Terms of Use.';
        valid = false;
    }

    if (!valid) return;

    // Check email not already registered
    const users = getUsers();
    if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) {
        setFieldError('sg-email-group', 'sg-email-err', 'An account with this email already exists.');
        toast('Email already registered. Please sign in.', 'error');
        return;
    }

    setLoading('signupBtn', null, null, true);
    await new Promise(r => setTimeout(r, 1000));

    const newUser = {
        id:        crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(),
        firstName,
        lastName,
        email,
        role,
        password:  btoa(password),   // base64 — demo only
        createdAt: Date.now()
    };

    users.push(newUser);
    saveUsers(users);

    // Auto-login
    setSession(newUser, false);

    toast(`Account created! Welcome, ${firstName}! Redirecting...`, 'success', 2500);

    setTimeout(() => {
        window.location.href = REDIR_URL;
    }, 1200);
});

// -------------------------------------------------------
// Keyboard accessibility — close modal on Escape
// -------------------------------------------------------
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const modal = document.getElementById('termsModal');
        if (!modal.classList.contains('hidden')) closeTerms();
    }
});

// -------------------------------------------------------
// Live validation feedback on blur
// -------------------------------------------------------
document.getElementById('loginEmail').addEventListener('blur', function() {
    const v = this.value.trim();
    if (v && !isValidEmail(v)) {
        setFieldError('lg-email-group', 'lg-email-err', 'Enter a valid email address.');
    } else {
        clearFieldError('lg-email-group', 'lg-email-err');
    }
});

document.getElementById('signupEmail').addEventListener('blur', function() {
    const v = this.value.trim();
    if (v && !isValidEmail(v)) {
        setFieldError('sg-email-group', 'sg-email-err', 'Enter a valid email address.');
    } else {
        clearFieldError('sg-email-group', 'sg-email-err');
    }
});

document.getElementById('signupConfirm').addEventListener('input', function() {
    const pw   = document.getElementById('signupPassword').value;
    const conf = this.value;
    if (conf && pw !== conf) {
        setFieldError('sg-conf-group', 'sg-conf-err', 'Passwords do not match.');
    } else {
        clearFieldError('sg-conf-group', 'sg-conf-err');
    }
});
