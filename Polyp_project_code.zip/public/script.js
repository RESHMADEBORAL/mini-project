// Empty string = relative URL → works on both port 3000 (via proxy) and port 5000 (direct Flask)
const FLASK_API_URL = '';

// DOM Elements — declared here, assigned after DOM ready
let uploadArea, imageInput, browseButton, resultsSection, loadingSpinner, errorMessage;
let statusDot, statusText;

let currentResults = null;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    // Assign DOM elements after page is loaded
    uploadArea     = document.getElementById('uploadArea');
    imageInput     = document.getElementById('imageInput');
    browseButton   = document.querySelector('.browse-button');
    resultsSection = document.getElementById('resultsSection');
    loadingSpinner = document.getElementById('loadingSpinner');
    errorMessage   = document.getElementById('errorMessage');
    statusDot      = document.getElementById('statusDot');
    statusText     = document.getElementById('statusText');

    setupEventListeners();
    checkServerHealth();
    // Check server health every 10 seconds
    setInterval(checkServerHealth, 10000);
});

// Event Listeners
function setupEventListeners() {
    // File input
    imageInput.addEventListener('change', handleFileSelect);
    browseButton.addEventListener('click', () => imageInput.click());

    // Drag and drop
    uploadArea.addEventListener('dragover', handleDragOver);
    uploadArea.addEventListener('dragleave', handleDragLeave);
    uploadArea.addEventListener('drop', handleDrop);

    // Result buttons
    document.getElementById('downloadResultsBtn').addEventListener('click', downloadResults);
    document.getElementById('analyzeAnotherBtn').addEventListener('click', resetForm);


}

// Drag and Drop Handlers
function handleDragOver(e) {
    e.preventDefault();
    uploadArea.classList.add('dragover');
}

function handleDragLeave(e) {
    e.preventDefault();
    uploadArea.classList.remove('dragover');
}

function handleDrop(e) {
    e.preventDefault();
    uploadArea.classList.remove('dragover');
    const files = e.dataTransfer.files;
    if (files.length > 0) {
        imageInput.files = files;
        handleFileSelect({ target: { files } });
    }
}

// File Selection Handler
async function handleFileSelect(e) {
    const files = e.target.files;
    if (files.length === 0) return;

    const file = files[0];

    // Validate file
    if (!['image/png', 'image/jpeg'].includes(file.type)) {
        showError('Invalid file type. Please upload PNG or JPG image.');
        return;
    }

    if (file.size > 10 * 1024 * 1024) {
        showError('File size exceeds 10MB limit.');
        return;
    }

    // Process file
    await processImage(file);
}

// Process Image
async function processImage(file) {
    showLoading(true);
    hideError();

    try {
        const formData = new FormData();
        formData.append('image', file);

        const response = await fetch(`${FLASK_API_URL}/api/predict`, {
            method: 'POST',
            body: formData,
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Prediction failed');
        }

        const data = await response.json();
        displayResults(data);
        currentResults = data;
    } catch (error) {
        console.error('Error:', error);
        showError(`Error: ${error.message}`);
    } finally {
        showLoading(false);
    }
}

// Display Results
function displayResults(data) {
    const {
        prediction,
        prediction_class,
        rejection_reason,
        filename,
        original_image,
        segmentation_mask,
        overlay_image,
        gradcam_heatmap,
        bbox_image,
        bounding_boxes,
        statistics
    } = data;

    // ---- Determine display class ----
    const predClass = prediction_class || prediction || 'Unknown';

    const isPolyp    = predClass === 'Polyp Detected';
    const isNonPolyp = predClass === 'Non-Polyp Lesion Detected';
    const isUnknown  = predClass === 'Unknown / Requires Review';
    const isNormal   = predClass === 'Normal Colon';

    // ---- Prediction badge ----
    const badge = document.getElementById('predictionBadge');
    if (badge) {
        badge.textContent = predClass;
        badge.className = 'prediction-badge';
        if (isPolyp)    badge.classList.add('badge-polyp');
        else if (isNonPolyp) badge.classList.add('badge-non-polyp');
        else if (isUnknown)  badge.classList.add('badge-unknown');
        else                 badge.classList.add('badge-normal');
    }

    const confBadge = document.getElementById('confidenceBadge');
    if (confBadge) {
        const conf = statistics?.raw_confidence ?? statistics?.detection_confidence ?? 0;
        confBadge.textContent = `Confidence: ${Math.round(conf)}%`;
    }

    // ---- Prediction text ----
    const predictionText = document.getElementById('predictionResult');
    const filenameText   = document.getElementById('filenameDisplay');
    predictionText.textContent = `Prediction: ${predClass}`;
    filenameText.textContent   = `File: ${filename || '-'}`;

    predictionText.className = 'result-text';
    if (isPolyp)    predictionText.classList.add('polyp-detected');
    else if (isNonPolyp) predictionText.classList.add('non-polyp-detected');
    else if (isUnknown)  predictionText.classList.add('unknown-detected');
    else                 predictionText.classList.add('normal-annotation');

    // ---- Rejection reason note ----
    const noteBox  = document.getElementById('rejectionNoteBox');
    const noteText = document.getElementById('rejectionNoteText');
    if (rejection_reason && noteBox && noteText) {
        noteText.textContent = rejection_reason;
        noteBox.classList.remove('hidden');
    } else if (noteBox) {
        noteBox.classList.add('hidden');
    }

    const rejRow  = document.getElementById('rejectionReasonRow');
    const rejSpan = document.getElementById('rejectionReason');
    if (rejection_reason && rejRow && rejSpan) {
        rejSpan.textContent  = rejection_reason;
        rejRow.style.display = 'block';
    } else if (rejRow) {
        rejRow.style.display = 'none';
    }

    // ---- Images ----
    document.getElementById('originalImage').src     = `data:image/png;base64,${original_image}`;
    document.getElementById('segmentationMask').src  = `data:image/png;base64,${segmentation_mask}`;
    document.getElementById('overlayImage').src      = `data:image/png;base64,${overlay_image}`;
    document.getElementById('gradcamHeatmap').src    = `data:image/png;base64,${gradcam_heatmap}`;

    const bboxImgEl = document.getElementById('bboxImage');
    if (bboxImgEl) {
        bboxImgEl.src = bbox_image
            ? `data:image/png;base64,${bbox_image}`
            : `data:image/png;base64,${original_image}`;
    }

    // ---- Polyp count ----
    const polypCount = isPolyp && bounding_boxes ? bounding_boxes.length : 0;
    document.getElementById('kpiPolypCount').textContent = polypCount;

    // ---- Confidence / KPI ----
    const rawConf = statistics?.raw_confidence ?? statistics?.detection_confidence ?? 0;
    document.getElementById('kpiModelConfidence').textContent = `${Math.round(rawConf)}%`;
    document.getElementById('kpiFinalOutput').textContent     = predClass;

    const kpiPredClass = document.getElementById('kpiPredClass');
    if (kpiPredClass) {
        kpiPredClass.textContent  = predClass;
        kpiPredClass.className    = 'kpi-pred-badge';
        if (isPolyp)    kpiPredClass.classList.add('badge-polyp');
        else if (isNonPolyp) kpiPredClass.classList.add('badge-non-polyp');
        else if (isUnknown)  kpiPredClass.classList.add('badge-unknown');
        else                 kpiPredClass.classList.add('badge-normal');
    }

    const kpiConf = document.getElementById('kpiConfidence');
    if (kpiConf) kpiConf.textContent = `${Math.round(rawConf)}%`;

    // ---- Summary panel ----
    document.getElementById('summaryDiagnosis').textContent = predClass;
    document.getElementById('summaryUpdate').textContent    = new Date().toLocaleString();

    const actionEl = document.getElementById('summaryAction');
    if (isPolyp) {
        actionEl.textContent = 'Refer to clinical review — polyp region detected';
    } else if (isNonPolyp) {
        actionEl.textContent = 'Refer to clinical review — non-polyp lesion region detected';
    } else if (isUnknown) {
        actionEl.textContent = 'Manual clinical review recommended — model confidence is low';
    } else {
        actionEl.textContent = 'Follow normal protocol — no significant finding detected';
    }

    // ---- Analysis preview ----
    const analysisPreview = document.getElementById('analysisPreviewImg');
    analysisPreview.src = `data:image/png;base64,${overlay_image || original_image}`;

    updateTrendVisualization([70, 78, 83, 91, 88, 92, 94]);

    // ---- Show results ----
    resultsSection.classList.remove('hidden');
    resultsSection.scrollIntoView({ behavior: 'smooth' });
}

function updateTrendVisualization(values) {
    const trendBars = document.getElementById('trendBars');
    trendBars.innerHTML = '';
    values.forEach((v) => {
        const bar = document.createElement('div');
        bar.className = 'trend-bar';
        bar.style.width = `${Math.min(100, Math.max(8, v))}%`;
        trendBars.appendChild(bar);
    });
}

// =============================================
// PDF Report Generator
// =============================================
async function downloadResults() {
    if (!currentResults) return;

    const btn = document.getElementById('downloadResultsBtn');
    btn.disabled = true;
    btn.innerHTML = `<span style="display:inline-flex;align-items:center;gap:8px;">
        <svg class="spin-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
        Generating PDF...
    </span>`;

    try {
        const pdf = await buildPDFBlob(currentResults);
        const url = URL.createObjectURL(pdf);
        const a = document.createElement('a');
        a.href = url;
        a.download = `polyp_report_${Date.now()}.pdf`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(url), 3000);
    } catch (err) {
        console.error('PDF error:', err);
        showError('Failed to generate PDF: ' + err.message);
    } finally {
        btn.disabled = false;
        btn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
            <polyline points="7 10 12 15 17 10"></polyline>
            <line x1="12" y1="15" x2="12" y2="3"></line>
        </svg> Download PDF Report`;
    }
}

// ---- PDF builder (pure Canvas → PDF binary) ----
async function buildPDFBlob(data) {
    const PAGE_W = 595;   // A4 pt width
    const PAGE_H = 842;   // A4 pt height
    const MARGIN = 40;
    const CONTENT_W = PAGE_W - MARGIN * 2;

    const pages = [];

    // --- PAGE 1: Summary Analysis ---
    pages.push(await buildSummaryPage(data, PAGE_W, PAGE_H, MARGIN, CONTENT_W));

    // --- PAGE 2: Analysis Results (images) ---
    pages.push(await buildImagesPage(data, PAGE_W, PAGE_H, MARGIN, CONTENT_W));

    // --- PAGE 3: Parameter Results ---
    pages.push(await buildParametersPage(data, PAGE_W, PAGE_H, MARGIN, CONTENT_W));

    return assemblePDF(pages, PAGE_W, PAGE_H);
}

function hexColor(hex) {
    const r = parseInt(hex.slice(1,3),16)/255;
    const g = parseInt(hex.slice(3,5),16)/255;
    const b = parseInt(hex.slice(5,7),16)/255;
    return {r, g, b};
}

async function buildSummaryPage(data, W, H, M, CW) {
    const canvas = document.createElement('canvas');
    const SCALE = 2;
    canvas.width  = W * SCALE;
    canvas.height = H * SCALE;
    const ctx = canvas.getContext('2d');
    ctx.scale(SCALE, SCALE);

    const isPolyp    = data.prediction === 'Polyp Detected';
    const isNonPolyp = data.prediction === 'Non-Polyp Lesion Detected';
    const isUnknown  = data.prediction === 'Unknown / Requires Review';
    const conf    = data.statistics?.detection_confidence ?? 0;
    const pct     = data.statistics?.detection_percentage ?? 0;
    const now     = new Date().toLocaleString();

    // verdict colour
    let badgeColour;
    if (isPolyp)    badgeColour = '#dc2626';
    else if (isNonPolyp) badgeColour = '#ea580c';
    else if (isUnknown)  badgeColour = '#d97706';
    else                 badgeColour = '#059669';

    // --- Background gradient ---
    const bg = ctx.createLinearGradient(0,0,0,H);
    bg.addColorStop(0,'#0f172a');
    bg.addColorStop(1,'#1e293b');
    ctx.fillStyle = bg;
    ctx.fillRect(0,0,W,H);

    // Header bar
    const hdr = ctx.createLinearGradient(0,0,CW+2*M,0);
    hdr.addColorStop(0, isPolyp ? '#dc2626' : isNonPolyp ? '#ea580c' : isUnknown ? '#d97706' : '#059669');
    hdr.addColorStop(1, isPolyp ? '#991b1b' : isNonPolyp ? '#9a3412' : isUnknown ? '#92400e' : '#065f46');
    ctx.fillStyle = hdr;
    roundRect(ctx, 0, 0, W, 110, 0);

    // Header text
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 26px Arial';
    ctx.fillText('Polyp Detection & Segmentation System', M, 42);
    ctx.font = '14px Arial';
    ctx.fillStyle = 'rgba(255,255,255,0.8)';
    ctx.fillText('AI-Powered Medical Image Analysis — Clinical Report', M, 68);
    ctx.fillText(`Generated: ${now}`, M, 90);

    // Section label
    sectionLabel(ctx, 'SECTION 1 — SUMMARY ANALYSIS', M, 128, CW);

    // Verdict badge
    ctx.fillStyle = badgeColour;
    roundRect(ctx, M, 145, CW, 64, 10);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 24px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(data.prediction, W/2, 184);
    ctx.textAlign = 'left';

    // Confidence ring-style bar
    let y = 232;
    metricRow(ctx, M, y, CW, 'Model Confidence', `${Math.round(conf)}%`, conf, isPolyp ? '#f87171':'#34d399');
    y += 60;
    metricRow(ctx, M, y, CW, 'Damage Occupancy Rate (DOR)', `${pct.toFixed(2)}%`, Math.min(pct*5,100), isPolyp ? '#fb923c':'#38bdf8');
    y += 60;

    // Summary cards
    y += 10;
    const cardData = [
        { label: 'Prediction',    value: data.prediction },
        { label: 'Recommendation', value: isPolyp ? 'Refer to clinical review' : isNonPolyp ? 'Refer to clinical review — non-polyp lesion' : isUnknown ? 'Manual review recommended' : 'Follow normal protocol' },
        { label: 'Image File',    value: data.filename || '-' },
        { label: 'Model',         value: 'Polyp Detection U-Net v4.0' },
        { label: 'Analysis Time', value: now },
        { label: 'Note',          value: 'Research prototype. Not a clinical diagnosis.' },
    ];
    const cardW = (CW - 16) / 2;
    cardData.forEach((item, i) => {
        const col = i % 2;
        const row = Math.floor(i / 2);
        const cx = M + col * (cardW + 16);
        const cy = y + row * 72;
        ctx.fillStyle = 'rgba(255,255,255,0.07)';
        roundRect(ctx, cx, cy, cardW, 58, 8);
        ctx.fillStyle = 'rgba(255,255,255,0.45)';
        ctx.font = '10px Arial';
        ctx.fillText(item.label.toUpperCase(), cx+12, cy+18);
        ctx.fillStyle = '#f1f5f9';
        ctx.font = 'bold 13px Arial';
        ctx.fillText(item.value, cx+12, cy+40);
    });

    y += Math.ceil(cardData.length/2)*72 + 20;

    // Clinical note box
    ctx.fillStyle = 'rgba(234,179,8,0.15)';
    roundRect(ctx, M, y, CW, 72, 8);
    ctx.fillStyle = '#fbbf24';
    ctx.font = 'bold 11px Arial';
    ctx.fillText('⚠  CLINICAL DISCLAIMER', M+14, y+20);
    ctx.fillStyle = 'rgba(255,255,255,0.7)';
    ctx.font = '10px Arial';
    wrapText(ctx, 'This report is generated by an AI model for research and clinical support only. It is not a substitute for professional medical diagnosis. Always consult a qualified healthcare professional.', M+14, y+36, CW-28, 14);

    // Footer
    pageFooter(ctx, W, H, M, 1, 3);

    return canvasToDataURL(canvas);
}

async function buildImagesPage(data, W, H, M, CW) {
    const canvas = document.createElement('canvas');
    const SCALE = 2;
    canvas.width  = W * SCALE;
    canvas.height = H * SCALE;
    const ctx = canvas.getContext('2d');
    ctx.scale(SCALE, SCALE);

    // Background
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0,0,W,H);

    // Mini header
    ctx.fillStyle = '#1e3a5f';
    roundRect(ctx, 0, 0, W, 70, 0);
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 18px Arial';
    ctx.fillText('Polyp Detection & Segmentation System', M, 30);
    ctx.fillStyle = 'rgba(255,255,255,0.6)';
    ctx.font = '11px Arial';
    ctx.fillText('AI-Powered Medical Image Analysis — Clinical Report', M, 50);

    sectionLabel(ctx, 'SECTION 2 — ANALYSIS RESULTS', M, 88, CW);

    const imgDefs = [
        { id: 'originalImage',    label: 'Original Image',       desc: 'Unprocessed input' },
        { id: 'segmentationMask', label: 'Segmentation Mask',    desc: 'Binary polyp region' },
        { id: 'overlayImage',     label: 'Overlay Detection',    desc: 'Mask on original' },
        { id: 'gradcamHeatmap',   label: 'Grad-CAM Heatmap',     desc: 'Model attention map' },
    ];

    const cols = 2;
    const imgW = (CW - 16) / cols;
    const imgH = imgW * 0.75;
    let startY = 108;

    for (let i = 0; i < imgDefs.length; i++) {
        const col = i % cols;
        const row = Math.floor(i / cols);
        const x = M + col * (imgW + 16);
        const y = startY + row * (imgH + 56);

        // Card bg
        ctx.fillStyle = 'rgba(255,255,255,0.06)';
        roundRect(ctx, x, y, imgW, imgH + 44, 10);

        // Card title
        ctx.fillStyle = '#94a3b8';
        ctx.font = '9px Arial';
        ctx.fillText(imgDefs[i].desc.toUpperCase(), x+10, y+14);
        ctx.fillStyle = '#f1f5f9';
        ctx.font = 'bold 12px Arial';
        ctx.fillText(imgDefs[i].label, x+10, y+30);

        // Draw image
        const imgEl = document.getElementById(imgDefs[i].id);
        if (imgEl && imgEl.src && imgEl.naturalWidth > 0) {
            const scale = Math.min((imgW-20) / imgEl.naturalWidth, (imgH-8) / imgEl.naturalHeight);
            const dw = imgEl.naturalWidth * scale;
            const dh = imgEl.naturalHeight * scale;
            const dx = x + (imgW - dw) / 2;
            const dy = y + 36 + ((imgH-36) - dh)/2;
            try { ctx.drawImage(imgEl, dx, dy, dw, dh); } catch(e) {}
        }
    }

    pageFooter(ctx, W, H, M, 2, 3);
    return canvasToDataURL(canvas);
}

async function buildParametersPage(data, W, H, M, CW) {
    const canvas = document.createElement('canvas');
    const SCALE = 2;
    canvas.width  = W * SCALE;
    canvas.height = H * SCALE;
    const ctx = canvas.getContext('2d');
    ctx.scale(SCALE, SCALE);

    const stats = data.statistics || {};
    const isPolyp = data.prediction === 'Polyp Detected';

    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0,0,W,H);

    // Mini header
    ctx.fillStyle = '#1e3a5f';
    roundRect(ctx, 0, 0, W, 70, 0);
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 18px Arial';
    ctx.fillText('Polyp Detection & Segmentation System', M, 30);
    ctx.fillStyle = 'rgba(255,255,255,0.6)';
    ctx.font = '11px Arial';
    ctx.fillText('AI-Powered Medical Image Analysis — Clinical Report', M, 50);

    sectionLabel(ctx, 'SECTION 3 — PARAMETER RESULTS', M, 88, CW);

    // --- Detailed metrics table ---
    const rows = [
        ['Parameter', 'Value', 'Notes'],
        ['Prediction', data.prediction, isPolyp ? 'Abnormality detected' : 'No abnormality'],
        ['Model Confidence', `${Math.round(stats.detection_confidence ?? 0)}%`, 'Mean prob in detected region'],
        ['Damage Occupancy Rate', `${(stats.detection_percentage ?? 0).toFixed(2)}%`, 'Area fraction of polyp mask'],
        ['Detected Area (px)', `${(stats.detected_area_pixels ?? 0).toLocaleString()}`, 'Pixels classified as polyp'],
        ['Total Image Area (px)', `${(stats.total_pixels ?? 0).toLocaleString()}`, 'Full image pixel count'],
        ['Image Width', `${stats.original_dimensions?.width ?? '-'} px`, 'Original image width'],
        ['Image Height', `${stats.original_dimensions?.height ?? '-'} px`, 'Original image height'],
        ['File Name', data.filename || '-', 'Uploaded image file'],
        ['Analysis Timestamp', new Date().toLocaleString(), 'Report generation time'],
    ];

    let y = 110;
    const col0 = M,  w0 = 160;
    const col1 = M + w0 + 8, w1 = 100;
    const col2 = M + w0 + w1 + 16, w2 = CW - w0 - w1 - 16;
    const ROW_H = 24;

    rows.forEach((row, i) => {
        const isHeader = i === 0;
        const bg = isHeader ? '#1e40af' : i % 2 === 0 ? 'rgba(255,255,255,0.04)' : 'rgba(255,255,255,0.08)';
        ctx.fillStyle = bg;
        ctx.fillRect(M, y, CW, ROW_H);

        ctx.fillStyle = isHeader ? '#fff' : '#cbd5e1';
        ctx.font = isHeader ? 'bold 11px Arial' : '10px Arial';
        ctx.fillText(row[0], col0+6, y + ROW_H - 8);

        ctx.fillStyle = isHeader ? '#fff' : (i===0 ? '#fff' : (isPolyp && i===1 ? '#f87171' : '#e2e8f0'));
        ctx.font = isHeader ? 'bold 11px Arial' : 'bold 10px Arial';
        ctx.fillText(row[1], col1+4, y + ROW_H - 8);

        ctx.fillStyle = isHeader ? '#bfdbfe' : 'rgba(255,255,255,0.4)';
        ctx.font = '9px Arial';
        ctx.fillText(row[2], col2+4, y + ROW_H - 8);

        y += ROW_H;
    });

    // Separator + visual bar chart for key metrics
    y += 20;
    ctx.fillStyle = 'rgba(255,255,255,0.12)';
    ctx.fillRect(M, y, CW, 1);
    y += 16;

    ctx.fillStyle = '#94a3b8';
    ctx.font = 'bold 11px Arial';
    ctx.fillText('KEY METRICS OVERVIEW', M, y);
    y += 14;

    const barMetrics = [
        { label: 'Model Confidence',        value: stats.detection_confidence ?? 0, color: '#60a5fa' },
        { label: 'Damage Occupancy Rate ×5', value: Math.min((stats.detection_percentage ?? 0)*5, 100), color: '#f97316' },
        { label: 'Pixel Coverage',           value: stats.total_pixels ? (stats.detected_area_pixels/stats.total_pixels)*100 : 0, color: '#a78bfa' },
    ];

    barMetrics.forEach(m => {
        ctx.fillStyle = 'rgba(255,255,255,0.5)';
        ctx.font = '10px Arial';
        ctx.fillText(m.label, M, y+12);
        ctx.fillStyle = 'rgba(255,255,255,0.1)';
        ctx.fillRect(M+160, y, CW-160, 14);
        ctx.fillStyle = m.color;
        ctx.fillRect(M+160, y, (CW-160) * Math.min(m.value,100)/100, 14);
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 9px Arial';
        ctx.fillText(`${m.value.toFixed(1)}%`, M+160+4, y+11);
        y += 22;
    });

    pageFooter(ctx, W, H, M, 3, 3);
    return canvasToDataURL(canvas);
}

// ---- Drawing helpers ----
function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x+r, y);
    ctx.lineTo(x+w-r, y);
    ctx.quadraticCurveTo(x+w, y, x+w, y+r);
    ctx.lineTo(x+w, y+h-r);
    ctx.quadraticCurveTo(x+w, y+h, x+w-r, y+h);
    ctx.lineTo(x+r, y+h);
    ctx.quadraticCurveTo(x, y+h, x, y+h-r);
    ctx.lineTo(x, y+r);
    ctx.quadraticCurveTo(x, y, x+r, y);
    ctx.closePath();
    ctx.fill();
}

function sectionLabel(ctx, text, x, y, w) {
    ctx.fillStyle = 'rgba(99,102,241,0.25)';
    ctx.fillRect(x, y-14, w, 20);
    ctx.fillStyle = '#818cf8';
    ctx.font = 'bold 10px Arial';
    ctx.fillText(text, x+6, y);
}

function metricRow(ctx, x, y, w, label, valueText, pct, color) {
    ctx.fillStyle = 'rgba(255,255,255,0.06)';
    roundRect(ctx, x, y, w, 48, 8);
    ctx.fillStyle = 'rgba(255,255,255,0.5)';
    ctx.font = '11px Arial';
    ctx.fillText(label, x+12, y+17);
    ctx.fillStyle = '#f1f5f9';
    ctx.font = 'bold 20px Arial';
    ctx.fillText(valueText, x+12, y+40);
    // mini bar
    ctx.fillStyle = 'rgba(255,255,255,0.1)';
    ctx.fillRect(x + w - 180, y+14, 160, 10);
    ctx.fillStyle = color;
    ctx.fillRect(x + w - 180, y+14, 160 * Math.min(pct,100)/100, 10);
}

function pageFooter(ctx, W, H, M, page, total) {
    ctx.fillStyle = 'rgba(255,255,255,0.1)';
    ctx.fillRect(M, H-36, W-2*M, 1);
    ctx.fillStyle = 'rgba(255,255,255,0.35)';
    ctx.font = '9px Arial';
    ctx.textAlign = 'left';
    ctx.fillText('Polyp Detection & Segmentation System — For research and clinical support only', M, H-20);
    ctx.textAlign = 'right';
    ctx.fillText(`Page ${page} of ${total}`, W-M, H-20);
    ctx.textAlign = 'left';
}

function wrapText(ctx, text, x, y, maxW, lineH) {
    const words = text.split(' ');
    let line = '';
    for (const word of words) {
        const test = line + word + ' ';
        if (ctx.measureText(test).width > maxW && line) {
            ctx.fillText(line, x, y);
            line = word + ' ';
            y += lineH;
        } else {
            line = test;
        }
    }
    ctx.fillText(line, x, y);
}

function canvasToDataURL(canvas) {
    return canvas.toDataURL('image/jpeg', 0.92);
}

// ---- Minimal PDF assembler (JPEG pages) ----
function assemblePDF(pageDataURLs, W, H) {
    // Build a minimal valid PDF with one JPEG image per page
    const encoder = new TextEncoder();
    const parts = [];
    const offsets = [];
    let pos = 0;

    function write(str) {
        const bytes = encoder.encode(str);
        parts.push(bytes);
        pos += bytes.length;
        return bytes.length;
    }

    function writeBytes(buf) {
        parts.push(buf);
        pos += buf.length;
    }

    // Header
    write('%PDF-1.4\n%\xff\xff\xff\xff\n');

    const pageCount = pageDataURLs.length;
    const imageObjs = []; // {id, w, h, dataLen, offset}
    const pageObjs  = [];

    // Object IDs layout:
    // 1 = catalog, 2 = pages, 3..2+N = page objs, 3+N..2+2N = image objs
    const catalogId = 1;
    const pagesId   = 2;
    const firstPageId = 3;
    const firstImgId  = 3 + pageCount;

    // Write image objects first
    for (let i = 0; i < pageCount; i++) {
        const dataURL = pageDataURLs[i];
        const b64 = dataURL.split(',')[1];
        const raw = atob(b64);
        const imgBytes = new Uint8Array(raw.length);
        for (let j=0; j<raw.length; j++) imgBytes[j] = raw.charCodeAt(j);

        const imgId = firstImgId + i;
        offsets[imgId] = pos;
        write(`${imgId} 0 obj\n<< /Type /XObject /Subtype /Image /Width ${W*2} /Height ${H*2} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${imgBytes.length} >>\nstream\n`);
        writeBytes(imgBytes);
        write('\nendstream\nendobj\n');
        imageObjs.push({ id: imgId });
    }

    // Write page objects
    for (let i = 0; i < pageCount; i++) {
        const pageId = firstPageId + i;
        const imgId  = firstImgId  + i;
        offsets[pageId] = pos;

        const contentStr = `q ${W} 0 0 ${H} 0 0 cm /Im${i} Do Q`;
        const contentBytes = encoder.encode(contentStr);
        // content stream inline
        const streamId = firstImgId + pageCount + i;
        offsets[streamId] = pos;
        write(`${streamId} 0 obj\n<< /Length ${contentBytes.length} >>\nstream\n`);
        writeBytes(contentBytes);
        write('\nendstream\nendobj\n');

        offsets[pageId] = pos;
        write(`${pageId} 0 obj\n<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${W} ${H}] /Contents ${streamId} 0 R /Resources << /XObject << /Im${i} ${imgId} 0 R >> >> >>\nendobj\n`);
        pageObjs.push(pageId);
    }

    // Pages object
    offsets[pagesId] = pos;
    const kidsStr = pageObjs.map(id => `${id} 0 R`).join(' ');
    write(`${pagesId} 0 obj\n<< /Type /Pages /Kids [${kidsStr}] /Count ${pageCount} >>\nendobj\n`);

    // Catalog
    offsets[catalogId] = pos;
    write(`${catalogId} 0 obj\n<< /Type /Catalog /Pages ${pagesId} 0 R >>\nendobj\n`);

    // xref
    const xrefPos = pos;
    const totalObjs = firstImgId + pageCount*2; // images + content streams + pages + catalog
    write(`xref\n0 ${totalObjs + 1}\n0000000000 65535 f \n`);
    for (let id = 1; id <= totalObjs; id++) {
        const off = offsets[id] ?? 0;
        write(`${String(off).padStart(10,'0')} 00000 n \n`);
    }
    write(`trailer\n<< /Size ${totalObjs+1} /Root ${catalogId} 0 R >>\nstartxref\n${xrefPos}\n%%EOF\n`);

    // Merge all parts
    const totalLen = parts.reduce((s, p) => s + p.length, 0);
    const merged = new Uint8Array(totalLen);
    let off2 = 0;
    for (const p of parts) { merged.set(p, off2); off2 += p.length; }

    return new Blob([merged], { type: 'application/pdf' });
}

// Reset Form
function resetForm() {
    imageInput.value = '';
    resultsSection.classList.add('hidden');
    hideError();
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Server Health Check
async function checkServerHealth() {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);

    try {
        const response = await fetch(`${FLASK_API_URL}/api/health`, {
            signal: controller.signal
        });
        clearTimeout(timeoutId);

        // Our built-in /api/health always returns 200 with { flask: true/false }
        // Fallback: treat response.ok as connected for direct Flask usage
        let flaskUp = false;
        try {
            const data = await response.json();
            // New frontend_server.py format: { flask: true, status: 'ok' }
            if (typeof data.flask !== 'undefined') {
                flaskUp = data.flask === true;
            } else {
                // Direct Flask response: { status: 'ok' }
                flaskUp = response.ok && data.status === 'ok';
            }
        } catch (_) {
            flaskUp = response.ok;
        }

        if (flaskUp) {
            statusDot.classList.add('connected');
            statusText.textContent = 'Flask Server Connected';
            return true;
        } else {
            statusDot.classList.remove('connected');
            statusText.textContent = 'Flask Server Disconnected';
            return false;
        }
    } catch (error) {
        clearTimeout(timeoutId);
        statusDot.classList.remove('connected');
        statusText.textContent = error.name === 'AbortError'
            ? 'Flask Server Timeout'
            : 'Flask Server Disconnected';
        return false;
    }
}



// UI Helpers
function showLoading(show) {
    if (show) {
        loadingSpinner.classList.remove('hidden');
        resultsSection.classList.add('hidden');
    } else {
        loadingSpinner.classList.add('hidden');
    }
}

function showError(message) {
    errorMessage.textContent = message;
    errorMessage.classList.remove('hidden');
}

function hideError() {
    errorMessage.classList.add('hidden');
}

// Image to Base64 conversion helper
function imageToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result.split(',')[1]);
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}
