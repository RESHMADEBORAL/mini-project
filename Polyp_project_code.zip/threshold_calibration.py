"""
threshold_calibration.py
========================
Run on the VALIDATION set to determine the optimal confidence thresholds for:
  - POLYP_THRESHOLD      (sigmoid area mean to call a polyp)
  - UNKNOWN_THRESHOLD    (below this → "Unknown / Requires Review")

Usage:
    python threshold_calibration.py

Outputs:
    files/threshold_calibration.png  — PR curve + ROC curve
    files/thresholds.txt             — recommended threshold values
"""

import os
import sys
import numpy as np
import cv2
import tensorflow as tf
from tensorflow.keras.utils import CustomObjectScope
import matplotlib
matplotlib.use("Agg")          # non-interactive backend (no display needed)
import matplotlib.pyplot as plt
from data import load_data, read_image, read_mask
from train import iou, dice_coeff, dice_bce_loss

# ============================================================
# Helpers
# ============================================================
def predict_confidence(model, image_arr):
    """
    Run the segmentation model and return:
      pred_mask  : H×W float32 probability map
      mean_conf  : mean probability in activated region
      area_pct   : % of pixels above 0.5
    """
    inp  = np.expand_dims(image_arr.astype(np.float32), axis=0)
    pred = model.predict(inp, verbose=0)[0]          # H×W×1
    pred = pred.squeeze()                             # H×W

    activated = pred[pred > 0.5]
    mean_conf = float(np.mean(activated)) if len(activated) else 0.0
    area_pct  = float(np.mean(pred > 0.5)) * 100.0
    return pred, mean_conf, area_pct


def evaluate_thresholds(model, images, masks, area_thresholds, conf_thresholds):
    """
    Grid-search over area_threshold × conf_threshold.
    Returns a dict with precision, recall, F1 for each (area_t, conf_t) pair.
    """
    results = []

    for area_t in area_thresholds:
        for conf_t in conf_thresholds:
            tp = fp = fn = tn = 0
            for img_path, msk_path in zip(images, masks):
                img  = read_image(img_path)
                mask = read_mask(msk_path).squeeze()

                _, mean_conf, area_pct = predict_confidence(model, img)

                gt_polyp   = mask.sum() > 0          # ground truth: is there a polyp?
                pred_polyp = (area_pct >= area_t) and (mean_conf >= conf_t)

                if pred_polyp and gt_polyp:     tp += 1
                elif pred_polyp and not gt_polyp: fp += 1
                elif not pred_polyp and gt_polyp: fn += 1
                else:                            tn += 1

            precision = tp / (tp + fp + 1e-9)
            recall    = tp / (tp + fn + 1e-9)
            f1        = 2 * precision * recall / (precision + recall + 1e-9)
            fpr       = fp / (fp + tn + 1e-9)   # false-positive rate

            results.append({
                "area_t":    area_t,
                "conf_t":    conf_t,
                "precision": precision,
                "recall":    recall,
                "f1":        f1,
                "fpr":       fpr,
                "tp": tp, "fp": fp, "fn": fn, "tn": tn,
            })

    return results


def plot_pr_curve(results, save_path):
    """Plot Precision-Recall and FPR-Recall curves."""
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    fig.suptitle("Threshold Calibration – Polyp Detection", fontsize=14, fontweight="bold")

    # Group by area_threshold
    area_values = sorted(set(r["area_t"] for r in results))
    colors = plt.cm.viridis(np.linspace(0, 1, len(area_values)))

    for ax, (x_key, y_key, xlabel, title) in zip(axes, [
        ("recall", "precision", "Recall",          "Precision–Recall Curve"),
        ("recall", "fpr",       "Recall (TPR)",     "FPR vs. Recall (minimize FPR)"),
    ]):
        for area_t, color in zip(area_values, colors):
            subset = sorted(
                [r for r in results if r["area_t"] == area_t],
                key=lambda r: r["conf_t"]
            )
            x_vals = [r[x_key] for r in subset]
            y_vals = [r[y_key] for r in subset]
            ax.plot(x_vals, y_vals, "o-", color=color,
                    label=f"Area≥{area_t}%", markersize=4)

        ax.set_xlabel(xlabel, fontsize=11)
        ax.set_ylabel(y_key.replace("_", " ").title(), fontsize=11)
        ax.set_title(title, fontsize=12)
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
        ax.set_xlim(0, 1.05)
        ax.set_ylim(0, 1.05)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()
    print(f"[Calibration] Curves saved → {save_path}")


def recommend_thresholds(results):
    """
    Recommend thresholds that:
    1. Maximise F1 (primary)
    2. Keep FPR < 0.15  (medical priority: minimise false positive polyps)
    """
    # Medical priority: minimise false positives
    candidates = [r for r in results if r["fpr"] < 0.15]
    if not candidates:
        candidates = results   # relax if no candidate satisfies

    best = max(candidates, key=lambda r: r["f1"])
    return best


# ============================================================
# Main
# ============================================================
if __name__ == "__main__":
    os.makedirs("files", exist_ok=True)

    # Load model
    print("[Calibration] Loading model...")
    custom_objects = {"iou": iou, "dice_coeff": dice_coeff, "dice_bce_loss": dice_bce_loss}
    try:
        with CustomObjectScope(custom_objects):
            model = tf.keras.models.load_model("files/model.h5")
        print("[Calibration] Model loaded.")
    except Exception as e:
        print(f"[ERROR] Could not load model: {e}")
        sys.exit(1)

    # Load validation data
    (_, _), (valid_x, valid_y), _ = load_data("CVC-612/")
    if not valid_x:
        print("[ERROR] No validation images found.")
        sys.exit(1)
    print(f"[Calibration] Evaluating on {len(valid_x)} validation images...")

    # Grid search
    area_thresholds = [0.5, 1.0, 2.0, 3.0, 5.0]
    conf_thresholds = [0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80]

    results = evaluate_thresholds(model, valid_x, valid_y, area_thresholds, conf_thresholds)

    # Curves
    plot_pr_curve(results, "files/threshold_calibration.png")

    # Best thresholds
    best = recommend_thresholds(results)

    # The "unknown" threshold is slightly below the polyp confidence threshold
    polyp_conf_threshold   = round(best["conf_t"], 2)
    unknown_conf_threshold = round(max(0.30, best["conf_t"] - 0.15), 2)
    polyp_area_threshold   = best["area_t"]

    report = (
        f"Recommended Thresholds\n"
        f"{'='*40}\n"
        f"POLYP_CONF_THRESHOLD   = {polyp_conf_threshold}\n"
        f"UNKNOWN_CONF_THRESHOLD = {unknown_conf_threshold}\n"
        f"POLYP_AREA_THRESHOLD   = {polyp_area_threshold}\n"
        f"\nBest grid-search result:\n"
        f"  Precision : {best['precision']:.3f}\n"
        f"  Recall    : {best['recall']:.3f}\n"
        f"  F1        : {best['f1']:.3f}\n"
        f"  FPR       : {best['fpr']:.3f}\n"
        f"  TP={best['tp']}  FP={best['fp']}  FN={best['fn']}  TN={best['tn']}\n"
        f"\nPaste these values into app.py:\n"
        f"  POLYP_CONF_THRESHOLD   = {polyp_conf_threshold}\n"
        f"  UNKNOWN_CONF_THRESHOLD = {unknown_conf_threshold}\n"
        f"  POLYP_AREA_THRESHOLD   = {polyp_area_threshold}\n"
    )

    print("\n" + report)
    with open("files/thresholds.txt", "w") as f:
        f.write(report)
    print("[Calibration] Thresholds saved → files/thresholds.txt")
    print("[Calibration] Update POLYP_CONF_THRESHOLD and UNKNOWN_CONF_THRESHOLD in app.py")
