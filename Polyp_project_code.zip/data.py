
import os
import numpy as np
import cv2
from glob import glob
import tensorflow as tf
from sklearn.model_selection import train_test_split
import hashlib

# ============================================================
# Image size (must match model input)
# ============================================================
IMG_SIZE = 256

# ============================================================
# Duplicate / near-duplicate detection
# ============================================================
def file_md5(path):
    """Return MD5 hash of file bytes."""
    with open(path, 'rb') as f:
        return hashlib.md5(f.read()).hexdigest()

def find_duplicates(image_paths):
    """
    Return a list of (path_a, path_b) pairs that are exact byte-for-byte
    duplicates.  Prints a warning for each pair found.
    """
    seen = {}
    duplicates = []
    for p in image_paths:
        h = file_md5(p)
        if h in seen:
            duplicates.append((seen[h], p))
            print(f"[DUPLICATE] {seen[h]}  ==  {p}")
        else:
            seen[h] = p
    return duplicates

# ============================================================
# Paired data loading (polyp images + masks)
# ============================================================
def load_data(path, split=0.1, check_duplicates=True):
    """
    Load paired (image, mask) lists from CVC-style dataset.

    Returns:
        (train_x, train_y), (valid_x, valid_y), (test_x, test_y)
    """
    images = sorted(glob(os.path.join(path, "images", "*")))
    masks  = sorted(glob(os.path.join(path, "masks",  "*")))

    if len(images) != len(masks):
        raise ValueError(
            f"Image count ({len(images)}) != Mask count ({len(masks)}). "
            "Ensure every image has a corresponding mask with the same name."
        )

    # --- Verify pairing by stem name ---
    for img_p, msk_p in zip(images, masks):
        img_stem = os.path.splitext(os.path.basename(img_p))[0]
        msk_stem = os.path.splitext(os.path.basename(msk_p))[0]
        # Allow common conventions: mask filename may end with _mask
        if img_stem != msk_stem and img_stem not in msk_stem:
            print(f"[WARNING] Possible mismatch: image={img_stem}  mask={msk_stem}")

    if check_duplicates:
        dups = find_duplicates(images)
        if dups:
            print(f"[WARNING] Found {len(dups)} duplicate image pair(s). "
                  "Consider removing duplicates before training.")

    # --- Reproducible paired split ---
    total_size = len(images)
    valid_size = max(1, int(split * total_size))
    test_size  = max(1, int(split * total_size))

    # Split indices so images and masks stay paired
    indices = list(range(total_size))
    train_idx, valid_idx = train_test_split(indices, test_size=valid_size,  random_state=42)
    train_idx, test_idx  = train_test_split(train_idx, test_size=test_size, random_state=42)

    train_x = [images[i] for i in train_idx]
    train_y = [masks[i]  for i in train_idx]
    valid_x = [images[i] for i in valid_idx]
    valid_y = [masks[i]  for i in valid_idx]
    test_x  = [images[i] for i in test_idx]
    test_y  = [masks[i]  for i in test_idx]

    return (train_x, train_y), (valid_x, valid_y), (test_x, test_y)

# ============================================================
# Negative image loading
# ============================================================
def load_negatives(neg_dir):
    """
    Load hard-negative image paths from the negatives/ directory.
    No masks are required — a zero mask is returned during training.

    Expected structure:
        neg_dir/
            tumor/
            inflammatory/
            normal_variants/
            artifacts/
            mined/          ← populated by hard_negative_mining.py

    Returns:
        list of image paths
    """
    neg_images = []
    for ext in ("*.jpg", "*.jpeg", "*.png", "*.bmp"):
        neg_images.extend(glob(os.path.join(neg_dir, "**", ext), recursive=True))
    neg_images = sorted(neg_images)
    print(f"[Data] Loaded {len(neg_images)} hard-negative images from {neg_dir}")
    return neg_images

def load_data_with_negatives(polyp_path, neg_dir=None, split=0.1):
    """
    Load polyp (positive) data + optional hard negatives.

    Returns:
        (train_x, train_y, train_labels),
        (valid_x,  valid_y,  valid_labels),
        (test_x,   test_y,   test_labels)

    Labels: 1 = polyp, 0 = negative
    """
    (train_px, train_py), (valid_px, valid_py), (test_px, test_py) = load_data(
        polyp_path, split=split
    )

    # Polyp labels = 1
    train_labels = [1] * len(train_px)
    valid_labels = [1] * len(valid_px)
    test_labels  = [1] * len(test_px)

    if neg_dir and os.path.isdir(neg_dir):
        neg_images = load_negatives(neg_dir)
        if neg_images:
            neg_total = len(neg_images)
            neg_valid = max(1, int(split * neg_total))
            neg_test  = max(1, int(split * neg_total))
            neg_idx   = list(range(neg_total))

            ntr_idx, nv_idx = train_test_split(neg_idx, test_size=neg_valid,  random_state=42)
            ntr_idx, nt_idx = train_test_split(ntr_idx, test_size=neg_test,   random_state=42)

            ntr = [neg_images[i] for i in ntr_idx]
            nv  = [neg_images[i] for i in nv_idx]
            nt  = [neg_images[i] for i in nt_idx]

            # Negatives use empty string as mask path — handled by read_mask_or_zero
            train_px    += ntr;  train_py    += [''] * len(ntr)
            train_labels += [0] * len(ntr)
            valid_px    += nv;   valid_py    += [''] * len(nv)
            valid_labels += [0] * len(nv)
            test_px     += nt;   test_py     += [''] * len(nt)
            test_labels  += [0] * len(nt)

    return (
        (train_px, train_py, train_labels),
        (valid_px,  valid_py,  valid_labels),
        (test_px,   test_py,   test_labels),
    )

# ============================================================
# Image / Mask readers
# ============================================================
def read_image(path):
    """Decode, resize, and normalise an image for tf.numpy_function."""
    path = path.decode() if isinstance(path, bytes) else path
    x = cv2.imread(path, cv2.IMREAD_COLOR)
    if x is None:
        x = np.zeros((IMG_SIZE, IMG_SIZE, 3), dtype=np.float32)
    else:
        x = cv2.resize(x, (IMG_SIZE, IMG_SIZE))
    return (x / 255.0).astype(np.float32)

def read_mask(path):
    """
    Decode, resize, and normalise a binary mask.
    If path is empty string (negative sample), returns zero mask.
    """
    path = path.decode() if isinstance(path, bytes) else path
    if not path:
        return np.zeros((IMG_SIZE, IMG_SIZE, 1), dtype=np.float32)
    x = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    if x is None:
        return np.zeros((IMG_SIZE, IMG_SIZE, 1), dtype=np.float32)
    x = cv2.resize(x, (IMG_SIZE, IMG_SIZE))
    x = (x / 255.0).astype(np.float32)
    return np.expand_dims(x, axis=-1)

# ============================================================
# Augmentation helpers (colonoscopy-appropriate)
# ============================================================
def augment_pair(image, mask):
    """
    Apply the same random augmentation to an (image, mask) pair.
    Only transforms valid under colonoscopy imaging:
      - Horizontal / vertical flip
      - Small rotation (±15°)
      - Brightness / contrast jitter
    """
    # Random horizontal flip
    if np.random.rand() < 0.5:
        image = cv2.flip(image, 1)
        mask  = cv2.flip(mask.squeeze(), 1)[..., np.newaxis] if mask.ndim == 3 else cv2.flip(mask, 1)

    # Random vertical flip
    if np.random.rand() < 0.3:
        image = cv2.flip(image, 0)
        mask  = cv2.flip(mask.squeeze(), 0)[..., np.newaxis] if mask.ndim == 3 else cv2.flip(mask, 0)

    # Random rotation ±15°
    if np.random.rand() < 0.4:
        angle = np.random.uniform(-15, 15)
        M = cv2.getRotationMatrix2D((IMG_SIZE // 2, IMG_SIZE // 2), angle, 1.0)
        image = cv2.warpAffine(image, M, (IMG_SIZE, IMG_SIZE),
                               flags=cv2.INTER_LINEAR,
                               borderMode=cv2.BORDER_REFLECT_101)
        mask_2d = mask.squeeze() if mask.ndim == 3 else mask
        mask_2d = cv2.warpAffine(mask_2d, M, (IMG_SIZE, IMG_SIZE),
                                 flags=cv2.INTER_NEAREST,
                                 borderMode=cv2.BORDER_REFLECT_101)
        mask = mask_2d[..., np.newaxis] if mask.ndim == 3 else mask_2d

    # Brightness / contrast jitter (image only)
    if np.random.rand() < 0.5:
        alpha = np.random.uniform(0.8, 1.2)   # contrast
        beta  = np.random.uniform(-0.05, 0.05) # brightness
        image = np.clip(image * alpha + beta, 0.0, 1.0)

    return image.astype(np.float32), mask.astype(np.float32)

# ============================================================
# TF Dataset builders
# ============================================================
def _tf_parse(x, y):
    """Parse function without augmentation (validation/test)."""
    def _parse(x, y):
        return read_image(x), read_mask(y)
    x, y = tf.numpy_function(_parse, [x, y], [tf.float32, tf.float32])
    x.set_shape([IMG_SIZE, IMG_SIZE, 3])
    y.set_shape([IMG_SIZE, IMG_SIZE, 1])
    return x, y

def _tf_parse_augment(x, y):
    """Parse function with data augmentation (training only)."""
    def _parse_aug(x, y):
        img  = read_image(x)
        mask = read_mask(y)
        img, mask = augment_pair(img, mask)
        return img, mask
    x, y = tf.numpy_function(_parse_aug, [x, y], [tf.float32, tf.float32])
    x.set_shape([IMG_SIZE, IMG_SIZE, 3])
    y.set_shape([IMG_SIZE, IMG_SIZE, 1])
    return x, y

def tf_dataset(x, y, batch=8, augment=False, shuffle=False):
    """
    Build a tf.data.Dataset from image/mask path lists.

    Args:
        x       : list of image paths
        y       : list of mask paths (empty string for negatives)
        batch   : batch size
        augment : apply augmentation if True (use for training only)
        shuffle : shuffle dataset if True
    """
    dataset = tf.data.Dataset.from_tensor_slices((x, y))
    if shuffle:
        dataset = dataset.shuffle(buffer_size=len(x), reshuffle_each_iteration=True)
    parse_fn = _tf_parse_augment if augment else _tf_parse
    dataset = dataset.map(parse_fn, num_parallel_calls=tf.data.AUTOTUNE)
    dataset = dataset.batch(batch)
    dataset = dataset.prefetch(tf.data.AUTOTUNE)
    return dataset
