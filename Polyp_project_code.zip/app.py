import os
import sys
import numpy as np
import cv2
import tensorflow as tf
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename
from tensorflow.keras.utils import CustomObjectScope
from train import iou, dice_coeff, dice_bce_loss
import base64
from io import BytesIO
from PIL import Image

# ==============================
# Flask App Setup
# ==============================
app = Flask(__name__, static_folder='public', static_url_path='')
CORS(app)

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
MAX_FILE_SIZE = 10 * 1024 * 1024

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_FILE_SIZE

# ==============================
# Model Metadata
# ==============================
MODEL_NAME    = os.environ.get('MODEL_DISPLAY_NAME', 'Polyp Detection Unet Model')
MODEL_VERSION = os.environ.get('MODEL_VERSION', 'v4.0')

# ==============================
# Prediction Thresholds
# ==============================
# These values are calibrated on the validation set.
# Run threshold_calibration.py to recompute these after retraining.
#
# POLYP_CONF_THRESHOLD:   mean sigmoid in detected region must exceed this
#                         to call the result "Polyp Detected".
# UNKNOWN_CONF_THRESHOLD: below this the result is "Unknown / Requires Review".
# POLYP_AREA_THRESHOLD:   minimum % of pixels above 0.5 to trigger any detection.
# NON_POLYP_AREA_THRESHOLD: activations at this area but below polyp confidence
#                            suggest "Non-Polyp Lesion Detected".
#
POLYP_CONF_THRESHOLD      = float(os.environ.get('POLYP_CONF_THRESHOLD',   '0.65'))
UNKNOWN_CONF_THRESHOLD    = float(os.environ.get('UNKNOWN_CONF_THRESHOLD', '0.50'))
POLYP_AREA_THRESHOLD      = float(os.environ.get('POLYP_AREA_THRESHOLD',   '2.0'))
NON_POLYP_AREA_THRESHOLD  = float(os.environ.get('NON_POLYP_AREA_THRESHOLD','1.0'))

# ==============================
# Endoscopy Image Validation
# ==============================
# All valid scope images (colonoscopy, gastroscopy, rhinoscopy, hysteroscopy,
# ERCP, esophagoscopy, capsule endoscopy, cervicoscopy) share two properties:
#   1. They are COLOUR images (not grayscale like MRI/CT/X-ray)
#   2. They have a circular black vignette border from the scope lens
#
# ENDOSCOPY_GRAYSCALE_THRESHOLD:
#   Mean absolute per-channel difference.  If below this value the image is
#   effectively grayscale (MRI, CT, X-ray) and is rejected.
ENDOSCOPY_GRAYSCALE_THRESHOLD = float(os.environ.get('ENDOSCOPY_GRAYSCALE_THRESHOLD', '8.0'))
#
# ENDOSCOPY_CORNER_BRIGHTNESS:
#   Mean pixel brightness in the 4 corners (10 % of dims).  Scope images have
#   near-black corners; regular photos do not.
ENDOSCOPY_CORNER_BRIGHTNESS   = float(os.environ.get('ENDOSCOPY_CORNER_BRIGHTNESS',  '50.0'))
#
# ENDOSCOPY_CONTRAST_RATIO:
#   Ratio of centre brightness to corner brightness.  Scope images have a much
#   brighter centre than their dark corners (ratio > 2.5).
ENDOSCOPY_CONTRAST_RATIO      = float(os.environ.get('ENDOSCOPY_CONTRAST_RATIO',     '2.5'))

# ==============================
# Prediction Classes
# ==============================
CLASS_POLYP            = 'Polyp Detected'
CLASS_NON_POLYP_LESION = 'Non-Polyp Lesion Detected'
CLASS_UNKNOWN          = 'Unknown / Requires Review'
CLASS_NORMAL           = 'Normal Colon'

# ==============================
# Load Model
# ==============================
print("Loading model...")
try:
    custom_objects = {'iou': iou, 'dice_coeff': dice_coeff, 'dice_bce_loss': dice_bce_loss}
    with CustomObjectScope(custom_objects):
        _model_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'files', 'model.h5')
        model = tf.keras.models.load_model(_model_path)
    print("Model loaded successfully!")
except Exception as e:
    print(f"Error loading model: {e}")
    model = None

# ==============================
# Utility Functions
# ==============================
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def image_to_base64(image_array):
    image = Image.fromarray(image_array)
    buf = BytesIO()
    image.save(buf, format='PNG')
    buf.seek(0)
    return base64.b64encode(buf.getvalue()).decode()

# ==============================
# Grad-CAM (Updated for 4-class output)
# ==============================
def compute_gradcam(model, image, layer_name=None):
    """
    Compute Gradient-weighted Class Activation Map.

    For segmentation models, we take the gradient of the mean output
    with respect to the last convolutional feature map.

    Returns:
        cam  : H×W float32 in [0,1]
    """
    if layer_name is None:
        # Find last convolutional layer (4-D output)
        for layer in reversed(model.layers):
            if len(layer.output.shape) == 4:
                layer_name = layer.name
                break

    if layer_name is None:
        # Fallback: return uniform map
        return np.ones((256, 256), dtype=np.float32) * 0.5

    grad_model = tf.keras.models.Model(
        inputs=model.input,
        outputs=[model.get_layer(layer_name).output, model.output]
    )

    inputs = tf.cast(np.expand_dims(image, axis=0), tf.float32)

    with tf.GradientTape() as tape:
        conv_outputs, predictions = grad_model(inputs)
        # Use the mean of the highest-activating pixels as the loss signal
        # This makes the CAM focus on the most confident region rather than
        # the entire output (reduces spurious activations).
        flat_pred = tf.reshape(predictions, [-1])
        top_k     = tf.math.top_k(flat_pred, k=max(1, len(flat_pred) // 10)).values
        loss      = tf.reduce_mean(top_k)

    grads   = tape.gradient(loss, conv_outputs)
    if grads is None:
        return np.zeros((256, 256), dtype=np.float32)

    # ReLU-weighted spatial average (standard Grad-CAM)
    weights = tf.reduce_mean(tf.nn.relu(grads), axis=(0, 1, 2))
    cam     = tf.reduce_sum(weights * conv_outputs[0], axis=-1)
    cam     = tf.nn.relu(cam).numpy()
    cam     = cam / (cam.max() + 1e-8)

    return cv2.resize(cam.astype(np.float32), (256, 256))


def apply_heatmap(cam, original_image, colormap=cv2.COLORMAP_JET):
    heatmap = np.uint8(255 * cam)
    heatmap = cv2.applyColorMap(heatmap, colormap)
    overlay = cv2.addWeighted(original_image, 0.6, heatmap, 0.4, 0)
    return heatmap, overlay


# ==============================
# Endoscopy Validation
# ==============================
def is_valid_endoscopy_image(original_bgr):
    """
    Validates that the uploaded image is from an endoscope / medical scope.

    Accepted image types (all share the same two physical properties below):
      Colon & Rectum, Stomach, Nose & Sinuses, Uterus, Cervix,
      Gallbladder, Small Intestine, Esophagus.

    Two universal endoscope image properties are checked:

    1. COLOUR check — MRI, CT, X-ray images are near-grayscale.
       We measure the mean absolute difference across colour channels;
       values below ENDOSCOPY_GRAYSCALE_THRESHOLD indicate a grayscale image.

    2. CIRCULAR VIGNETTE check — every scope camera produces a circular
       bright field surrounded by a near-black border.  We compare the
       average brightness of the 4 corners (10 % of image dims) with the
       brightness of the central 50 % region.  Non-endoscopy images
       (regular photos, skin shots, eye images, etc.) will NOT have
       distinctly dark corners.

    Returns:
        (is_valid: bool, reason: str | None)
            reason is None when valid, otherwise a human-readable explanation.
    """
    h, w = original_bgr.shape[:2]
    img_f = original_bgr.astype(np.float32)

    # ---- 1. Grayscale / monochrome check --------------------------------
    r, g, b = img_f[:, :, 2], img_f[:, :, 1], img_f[:, :, 0]
    mean_ch_diff = (np.mean(np.abs(r - g)) +
                    np.mean(np.abs(r - b)) +
                    np.mean(np.abs(g - b))) / 3.0

    if mean_ch_diff < ENDOSCOPY_GRAYSCALE_THRESHOLD:
        return False, (
            "The uploaded image appears to be grayscale (e.g. MRI, CT scan, "
            "X-ray). This model only accepts colour endoscopy images from: "
            "Colon & Rectum, Stomach, Nose & Sinuses, Uterus, Cervix, "
            "Gallbladder, Small Intestine, or Esophagus."
        )

    # ---- 2. Circular vignette / dark-corner check -----------------------
    cx = max(1, int(w * 0.10))   # 10 % width
    cy = max(1, int(h * 0.10))   # 10 % height

    corner_pixels = np.concatenate([
        img_f[:cy,    :cx   ].reshape(-1),   # top-left
        img_f[:cy,    w-cx: ].reshape(-1),   # top-right
        img_f[h-cy:,  :cx   ].reshape(-1),   # bottom-left
        img_f[h-cy:,  w-cx: ].reshape(-1),   # bottom-right
    ])
    corner_brightness = float(np.mean(corner_pixels))

    centre = img_f[h//4 : 3*h//4, w//4 : 3*w//4]
    centre_brightness = float(np.mean(centre))

    contrast_ratio = centre_brightness / (corner_brightness + 1e-6)

    has_dark_corners   = corner_brightness  < ENDOSCOPY_CORNER_BRIGHTNESS
    has_good_contrast  = contrast_ratio     > ENDOSCOPY_CONTRAST_RATIO

    if not (has_dark_corners and has_good_contrast):
        return False, (
            f"Image does not appear to be from a medical endoscope "
            f"(corner brightness = {corner_brightness:.1f} / threshold < {ENDOSCOPY_CORNER_BRIGHTNESS}, "
            f"centre-to-corner ratio = {contrast_ratio:.2f} / threshold > {ENDOSCOPY_CONTRAST_RATIO}). "
            "Please upload a valid endoscopy image: Colonoscopy, Gastroscopy, "
            "Rhinoscopy, Hysteroscopy, Cervicoscopy, ERCP (Gallbladder), "
            "Capsule Endoscopy (Small Intestine), or Esophagoscopy."
        )

    return True, None


# ==============================
# 4-Class Prediction Logic
# ==============================
def classify_prediction(mean_conf, area_pct):
    """
    Translate (mean_confidence, area_pct) into one of four classes.

    Decision logic (in priority order):
      1. If area is large AND confidence is high → Polyp Detected
      2. If area is medium but confidence is below polyp threshold
         and above unknown threshold → Non-Polyp Lesion Detected
      3. If confidence is below unknown threshold → Unknown / Requires Review
      4. Otherwise → Normal Colon

    Args:
        mean_conf : float  — mean sigmoid probability in detected region
        area_pct  : float  — % of 256×256 pixels above 0.5 threshold

    Returns:
        (prediction_class: str, rejection_reason: str | None)
    """
    if area_pct >= POLYP_AREA_THRESHOLD:
        if mean_conf >= POLYP_CONF_THRESHOLD:
            return CLASS_POLYP, None

        elif mean_conf >= UNKNOWN_CONF_THRESHOLD:
            # Activated region is real but confidence too low for polyp call
            reason = (
                f"Model activated ({area_pct:.1f}% area, {mean_conf*100:.0f}% conf) "
                f"but confidence is below the polyp threshold ({POLYP_CONF_THRESHOLD*100:.0f}%). "
                "This may be a non-polyp lesion (tumor, fold, inflammation)."
            )
            return CLASS_NON_POLYP_LESION, reason

        else:
            # Low confidence despite some activation
            reason = (
                f"Model confidence ({mean_conf*100:.0f}%) is below the review "
                f"threshold ({UNKNOWN_CONF_THRESHOLD*100:.0f}%). Manual review recommended."
            )
            return CLASS_UNKNOWN, reason

    elif area_pct >= NON_POLYP_AREA_THRESHOLD:
        # Small activation but below polyp area threshold
        if mean_conf >= POLYP_CONF_THRESHOLD:
            reason = (
                f"Activated area ({area_pct:.1f}%) is below minimum polyp size "
                f"({POLYP_AREA_THRESHOLD}%). Could be a small lesion or artifact."
            )
            return CLASS_UNKNOWN, reason
        else:
            return CLASS_NORMAL, None

    else:
        return CLASS_NORMAL, None


# ==============================
# Routes
# ==============================
@app.route('/')
def index():
    return send_from_directory(app.static_folder, 'index.html')


@app.route('/api/predict', methods=['POST'])
def predict():
    if model is None:
        return jsonify({'error': 'Model not loaded'}), 500

    try:
        if 'image' not in request.files:
            return jsonify({'error': 'No image provided'}), 400

        file = request.files['image']

        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400

        if not allowed_file(file.filename):
            return jsonify({'error': 'Invalid file type'}), 400

        # Save file
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        # Read image
        original_image = cv2.imread(filepath)
        if original_image is None:
            return jsonify({'error': 'Invalid image'}), 400

        h, w = original_image.shape[:2]

        # ======================
        # Preprocess
        # ======================
        processed = cv2.resize(original_image, (256, 256))
        processed = processed.astype(np.float32) / 255.0

        # ======================
        # Segmentation
        # ======================
        pred = model.predict(np.expand_dims(processed, axis=0), verbose=0)[0]  # 256×256×1

        # Binary mask at 0.5 threshold
        mask = (pred > 0.5).astype(np.uint8) * 255
        mask_resized = cv2.resize(mask, (w, h))
        mask_resized = (mask_resized > 127).astype(np.uint8) * 255

        # ======================
        # Confidence Computation
        # ======================
        pred_resized = cv2.resize(pred, (w, h))
        high_conf_mask = pred_resized > 0.5
        if np.any(high_conf_mask):
            model_confidence = float(np.mean(pred_resized[high_conf_mask]))
        else:
            model_confidence = float(np.max(pred_resized))

        area_pixels = int(np.count_nonzero(mask_resized))
        total_pixels = w * h
        area_pct = float(area_pixels / total_pixels) * 100.0

        # ======================
        # Endoscopy Validation Guard
        # ======================
        is_valid, invalid_reason = is_valid_endoscopy_image(original_image)
        if not is_valid:
            prediction_class  = CLASS_UNKNOWN
            rejection_reason  = invalid_reason
        else:
            # ======================
            # 4-Class Decision
            # ======================
            prediction_class, rejection_reason = classify_prediction(model_confidence, area_pct)

        is_polyp           = prediction_class == CLASS_POLYP
        is_non_polyp_lesion = prediction_class == CLASS_NON_POLYP_LESION
        is_unknown          = prediction_class == CLASS_UNKNOWN
        is_normal           = prediction_class == CLASS_NORMAL

        # When no polyp, zero out mask for display
        if not is_polyp:
            display_mask = np.zeros_like(mask_resized)
            display_pct  = 0.0
            display_conf = model_confidence * 100.0  # still show raw confidence
        else:
            display_mask = mask_resized
            display_pct  = round(area_pct, 2)
            display_conf = model_confidence * 100.0

        print(f"DEBUG  class={prediction_class}  valid={is_valid}  area={area_pct:.2f}%  conf={model_confidence:.3f}")

        # ======================
        # Bounding Boxes
        # ======================
        bounding_boxes = []
        bbox_image = original_image.copy()

        if is_polyp:
            contours, _ = cv2.findContours(mask_resized, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            for cnt in contours:
                area = cv2.contourArea(cnt)
                if area < 100:
                    continue
                x_b, y_b, w_b, h_b = cv2.boundingRect(cnt)
                bounding_boxes.append({
                    'x': int(x_b), 'y': int(y_b),
                    'width': int(w_b), 'height': int(h_b),
                    'area': int(area)
                })
                cv2.rectangle(bbox_image, (x_b, y_b), (x_b + w_b, y_b + h_b), (0, 255, 0), 2)
                label = f'Polyp ({area} px)'
                (lw, lh), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
                cv2.rectangle(bbox_image, (x_b, y_b - lh - 6), (x_b + lw + 4, y_b), (0, 255, 0), -1)
                cv2.putText(bbox_image, label, (x_b + 2, y_b - 4),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)

        elif is_non_polyp_lesion:
            # Draw orange bounding boxes for non-polyp lesions
            contours, _ = cv2.findContours(mask_resized, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            for cnt in contours:
                area = cv2.contourArea(cnt)
                if area < 100:
                    continue
                x_b, y_b, w_b, h_b = cv2.boundingRect(cnt)
                bounding_boxes.append({
                    'x': int(x_b), 'y': int(y_b),
                    'width': int(w_b), 'height': int(h_b),
                    'area': int(area)
                })
                cv2.rectangle(bbox_image, (x_b, y_b), (x_b + w_b, y_b + h_b), (0, 165, 255), 2)
                label = 'Non-Polyp Lesion'
                (lw, lh), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
                cv2.rectangle(bbox_image, (x_b, y_b - lh - 6), (x_b + lw + 4, y_b), (0, 165, 255), -1)
                cv2.putText(bbox_image, label, (x_b + 2, y_b - 4),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)

        # ======================
        # Overlay (Mask)
        # ======================
        if is_polyp:
            overlay = original_image.copy()
            red_mask = np.zeros_like(original_image)
            red_mask[:, :, 2] = display_mask
            overlay = cv2.addWeighted(overlay, 0.7, red_mask, 0.3, 0)
        elif is_non_polyp_lesion:
            overlay = original_image.copy()
            orange_mask = np.zeros_like(original_image)
            orange_mask[:, :, 1] = (display_mask * 0.6).astype(np.uint8)   # slight orange
            orange_mask[:, :, 2] = display_mask
            overlay = cv2.addWeighted(overlay, 0.7, orange_mask, 0.3, 0)
        else:
            display_mask = np.zeros_like(mask_resized)
            overlay = original_image.copy()

        # ======================
        # Grad-CAM (Updated)
        # ======================
        cam = compute_gradcam(model, processed)
        cam = cv2.resize(cam, (w, h))

        if is_polyp:
            # Red heatmap — high concern
            heatmap, gradcam_overlay = apply_heatmap(cam, original_image, cv2.COLORMAP_JET)
        elif is_non_polyp_lesion:
            # Orange heatmap — moderate concern
            heatmap, gradcam_overlay = apply_heatmap(cam, original_image, cv2.COLORMAP_HOT)
        elif is_unknown:
            # Yellow heatmap — uncertain
            heatmap, gradcam_overlay = apply_heatmap(cam, original_image, cv2.COLORMAP_AUTUMN)
        else:
            # Blue heatmap — no concern
            blue_heatmap = np.uint8(255 * cam)
            heatmap = np.zeros_like(original_image)
            heatmap[:, :, 0] = blue_heatmap
            gradcam_overlay = cv2.addWeighted(original_image, 0.7, heatmap, 0.3, 0)

        # ======================
        # Response
        # ======================
        response = {
            'success': True,
            'prediction':         prediction_class,
            'prediction_class':   prediction_class,
            'rejection_reason':   rejection_reason,

            'original_image':    image_to_base64(cv2.cvtColor(original_image, cv2.COLOR_BGR2RGB)),
            'segmentation_mask': image_to_base64(display_mask),
            'overlay_image':     image_to_base64(cv2.cvtColor(overlay, cv2.COLOR_BGR2RGB)),
            'bbox_image':        image_to_base64(cv2.cvtColor(bbox_image, cv2.COLOR_BGR2RGB)),

            'gradcam_heatmap': image_to_base64(cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB)),
            'gradcam_overlay': image_to_base64(cv2.cvtColor(gradcam_overlay, cv2.COLOR_BGR2RGB)),

            'bounding_boxes': bounding_boxes,

            'statistics': {
                'detected_area_pixels':    area_pixels if is_polyp else 0,
                'total_pixels':            total_pixels,
                'detection_percentage':    round(display_pct, 2),
                'detection_confidence':    round(display_conf, 2),
                'raw_confidence':          round(model_confidence * 100, 2),
                'raw_area_pct':            round(area_pct, 2),
                'polyp_conf_threshold':    round(POLYP_CONF_THRESHOLD * 100, 1),
                'unknown_conf_threshold':  round(UNKNOWN_CONF_THRESHOLD * 100, 1),
                'polyp_area_threshold':    POLYP_AREA_THRESHOLD,
                'original_dimensions': {
                    'width':  w,
                    'height': h,
                },
            },
            'filename': filename,
        }

        return jsonify(response), 200

    except Exception as e:
        print("Error:", e)
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500


@app.route('/api/health')
def health():
    return jsonify({
        'status': 'ok',
        'model':  'loaded' if model else 'not loaded',
    })


@app.route('/api/model-info')
def model_info():
    if model is None:
        return jsonify({'error': 'Model not loaded'}), 500

    return jsonify({
        'name':         MODEL_NAME,
        'version':      MODEL_VERSION,
        'input_shape':  str(model.input_shape),
        'output_shape': str(model.output_shape),
        'parameters':   int(model.count_params()),
        'thresholds': {
            'polyp_conf':      POLYP_CONF_THRESHOLD,
            'unknown_conf':    UNKNOWN_CONF_THRESHOLD,
            'polyp_area_pct':  POLYP_AREA_THRESHOLD,
        },
    })


# ==============================
# Run Server
# ==============================
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    host = '0.0.0.0'
    print(f"Running on http://{host}:{port}")
    app.run(debug=True, host=host, port=port)