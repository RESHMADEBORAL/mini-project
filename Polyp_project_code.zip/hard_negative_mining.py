"""
hard_negative_mining.py
=======================
Step-by-step pipeline to collect false-positive examples and mine
hard negatives for retraining.

Pipeline:
  1. Run model on a folder of NON-POLYP images.
  2. Find images where the model incorrectly predicts a polyp (false positives).
  3. Save those images to CVC-612/negatives/mined/
  4. Retrain with: python train.py   (train.py auto-loads negatives/mined/)

Usage:
    python hard_negative_mining.py --neg_dir CVC-612/negatives
    python hard_negative_mining.py --neg_dir CVC-612/negatives --area_threshold 2.0 --conf_threshold 0.60
"""

import os
import sys
import argparse
import shutil
import numpy as np
import cv2
from glob import glob
import tensorflow as tf
from tensorflow.keras.utils import CustomObjectScope
from tqdm import tqdm
from data import read_image
from train import iou, dice_coeff, dice_bce_loss

# ============================================================
# Argument parsing
# ============================================================
parser = argparse.ArgumentParser(description="Hard Negative Mining Pipeline")
parser.add_argument("--neg_dir",        type=str, default="CVC-612/negatives",
                    help="Directory containing non-polyp images (sub-folders supported)")
parser.add_argument("--area_threshold", type=float, default=2.0,
                    help="% of pixels above 0.5 to call 'polyp' (default: 2.0)")
parser.add_argument("--conf_threshold", type=float, default=0.60,
                    help="Mean confidence in activated region (default: 0.60)")
parser.add_argument("--model_path",    type=str, default="files/model.h5",
                    help="Path to trained model weights")
parser.add_argument("--output_dir",   type=str, default="CVC-612/negatives/mined",
                    help="Where to save false-positive images")
parser.add_argument("--save_vis",     action="store_true",
                    help="Save side-by-side image + heatmap for each FP")


def predict(model, image_arr):
    """Return (pred_mask H×W, mean_conf, area_pct) for a pre-processed image."""
    inp  = np.expand_dims(image_arr.astype(np.float32), axis=0)
    pred = model.predict(inp, verbose=0)[0].squeeze()   # H×W
    activated = pred[pred > 0.5]
    mean_conf = float(np.mean(activated)) if len(activated) else 0.0
    area_pct  = float(np.mean(pred > 0.5)) * 100.0
    return pred, mean_conf, area_pct


def make_vis(original_bgr, pred_mask, mean_conf, area_pct):
    """Build a 3-panel visualisation: original | mask overlay | heatmap."""
    H, W = pred_mask.shape
    orig_r = cv2.resize(original_bgr, (W, H))

    # Mask overlay (red)
    overlay = orig_r.copy()
    red_mask = np.zeros_like(orig_r)
    red_mask[:, :, 2] = (pred_mask * 255).astype(np.uint8)
    overlay  = cv2.addWeighted(overlay, 0.7, red_mask, 0.3, 0)

    # Heatmap
    heatmap = np.uint8(255 * pred_mask)
    heatmap = cv2.applyColorMap(heatmap, cv2.COLORMAP_JET)

    # Label
    label = f"FP  conf={mean_conf:.2f}  area={area_pct:.1f}%"
    for img in [orig_r, overlay, heatmap]:
        cv2.putText(img, label, (4, 14), cv2.FONT_HERSHEY_SIMPLEX,
                    0.4, (255, 255, 0), 1, cv2.LINE_AA)

    sep = np.ones((H, 4, 3), dtype=np.uint8) * 180
    return np.concatenate([orig_r, sep, overlay, sep, heatmap], axis=1)


# ============================================================
# Main
# ============================================================
if __name__ == "__main__":
    args = parser.parse_args()

    if not os.path.isdir(args.neg_dir):
        print(f"[ERROR] --neg_dir not found: {args.neg_dir}")
        print("  Create this directory and place non-polyp colonoscopy images inside.")
        print("  Suggested sub-folders:")
        print("    CVC-612/negatives/tumor/")
        print("    CVC-612/negatives/inflammatory/")
        print("    CVC-612/negatives/normal_variants/")
        print("    CVC-612/negatives/artifacts/   (blood, bubbles, stool, folds)")
        sys.exit(1)

    # Collect all images from neg_dir (excluding mined/ to avoid re-mining)
    exts = ["*.jpg", "*.jpeg", "*.png", "*.bmp"]
    all_neg = []
    for ext in exts:
        all_neg.extend(glob(os.path.join(args.neg_dir, "**", ext), recursive=True))
    # Exclude previously mined images
    all_neg = [p for p in all_neg if "mined" not in p.lower()]
    all_neg = sorted(set(all_neg))

    if not all_neg:
        print(f"[ERROR] No images found in {args.neg_dir}")
        print("  Add .jpg/.png images to this directory first.")
        sys.exit(1)

    print(f"[Mining] Found {len(all_neg)} non-polyp images to evaluate.")

    # Load model
    custom_objects = {"iou": iou, "dice_coeff": dice_coeff, "dice_bce_loss": dice_bce_loss}
    try:
        with CustomObjectScope(custom_objects):
            model = tf.keras.models.load_model(args.model_path)
        print(f"[Mining] Model loaded from {args.model_path}")
    except Exception as e:
        print(f"[ERROR] Could not load model: {e}")
        sys.exit(1)

    os.makedirs(args.output_dir, exist_ok=True)
    if args.save_vis:
        vis_dir = os.path.join(args.output_dir, "visualisations")
        os.makedirs(vis_dir, exist_ok=True)

    # -------------------------------------------------------
    # Mining loop
    # -------------------------------------------------------
    false_positives = []
    summary_rows = []

    for img_path in tqdm(all_neg, desc="Mining FP"):
        image_arr = read_image(img_path)
        pred_mask, mean_conf, area_pct = predict(model, image_arr)

        is_fp = (area_pct >= args.area_threshold) and (mean_conf >= args.conf_threshold)

        if is_fp:
            false_positives.append(img_path)
            # Copy to mined/
            dst = os.path.join(args.output_dir, os.path.basename(img_path))
            # Avoid overwriting if same filename from different sub-dirs
            if os.path.exists(dst):
                base, ext = os.path.splitext(os.path.basename(img_path))
                dst = os.path.join(args.output_dir, f"{base}_{len(false_positives)}{ext}")
            shutil.copy2(img_path, dst)

            # Optional visualisation
            if args.save_vis:
                orig_bgr = cv2.imread(img_path)
                if orig_bgr is not None:
                    vis = make_vis(orig_bgr, pred_mask, mean_conf, area_pct)
                    vis_name = os.path.splitext(os.path.basename(img_path))[0] + "_fp.png"
                    cv2.imwrite(os.path.join(vis_dir, vis_name), vis)

            summary_rows.append(
                f"  [FP] area={area_pct:.1f}%  conf={mean_conf:.2f}  {img_path}"
            )

    # -------------------------------------------------------
    # Report
    # -------------------------------------------------------
    print(f"\n{'='*55}")
    print(f"[Mining] Hard Negative Mining Complete")
    print(f"  Total evaluated : {len(all_neg)}")
    print(f"  False positives : {len(false_positives)}")
    print(f"  FP rate         : {len(false_positives)/len(all_neg)*100:.1f}%")
    print(f"  Saved to        : {args.output_dir}")
    print(f"{'='*55}")

    if summary_rows:
        print("\nFalse positive images:")
        for row in summary_rows:
            print(row)

    if false_positives:
        print(f"\n[NEXT STEP] Retrain the model with the mined hard negatives:")
        print(f"  python train.py")
        print(f"\n  The training script auto-loads all images from:")
        print(f"  {args.neg_dir}")
        print(f"\n  After retraining, run mining again to check improvement:")
        print(f"  python hard_negative_mining.py --neg_dir {args.neg_dir} --save_vis")
    else:
        print("\n[OK] No false positives found with the current thresholds.")
        print("  The model is NOT incorrectly classifying these negatives as polyps.")
        print("  If you expected FPs, try lowering --area_threshold or --conf_threshold.")
