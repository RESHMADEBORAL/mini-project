"""
start.py - Single-command launcher for PolySense
Starts both Flask backend (port 5000) and Frontend server (port 3000).

Usage:
    python start.py
"""

import subprocess
import sys
import os
import time
import threading
import signal

# ── Config ───────────────────────────────────────────────────────────────────
BASE_DIR     = os.path.dirname(os.path.abspath(__file__))
FLASK_PORT   = 5000
FRONT_PORT   = 3000
FLASK_SCRIPT = os.path.join(BASE_DIR, 'app.py')
FRONT_SCRIPT = os.path.join(BASE_DIR, 'frontend_server.py')

def _find_python():
    """Return a working python executable.
    Tries venv310/venv310_new first, then falls back to sys.executable.
    Validates each candidate actually runs before returning it."""
    import subprocess as _sp
    for venv_name in ('venv310', 'venv310_new'):
        candidate = os.path.join(BASE_DIR, venv_name, 'Scripts', 'python.exe')
        if os.path.isfile(candidate):
            try:
                _sp.check_output([candidate, '--version'], timeout=5)
                return candidate  # Works!
            except Exception:
                pass  # Broken venv (deleted Python install) — skip it
    # Last resort: whatever python launched this script
    return sys.executable

PYTHON = _find_python()

# ── ANSI colours ──────────────────────────────────────────────────────────────
RED    = '\033[91m'
GREEN  = '\033[92m'
YELLOW = '\033[93m'
CYAN   = '\033[96m'
BOLD   = '\033[1m'
RESET  = '\033[0m'

def tag(name, color):
    return f"{color}{BOLD}[{name}]{RESET}"

# ── Stream output from a process ─────────────────────────────────────────────
def stream_output(proc, label, color):
    try:
        for line in iter(proc.stdout.readline, b''):
            text = line.decode('utf-8', errors='replace').rstrip()
            if text:
                print(f"{tag(label, color)} {text}", flush=True)
    except Exception:
        pass

def stream_stderr(proc, label):
    try:
        for line in iter(proc.stderr.readline, b''):
            text = line.decode('utf-8', errors='replace').rstrip()
            if text:
                print(f"{tag(label, RED)} {text}", flush=True)
    except Exception:
        pass

# ── Main ──────────────────────────────────────────────────────────────────────
procs = []

def shutdown(sig=None, frame=None):
    print(f"\n{tag('LAUNCHER', RED)} Stopping all servers...", flush=True)
    for p in procs:
        try:
            p.terminate()
        except Exception:
            pass
    for p in procs:
        try:
            p.wait(timeout=5)
        except Exception:
            pass
    print(f"{tag('LAUNCHER', RED)} All servers stopped. Goodbye!", flush=True)
    sys.exit(0)

def run():
    print(f"\n{BOLD}{CYAN}{'='*55}{RESET}")
    print(f"{BOLD}{CYAN}  PolySense - Starting All Servers{RESET}")
    print(f"{BOLD}{CYAN}{'='*55}{RESET}\n")
    print(f"{tag('LAUNCHER', CYAN)} Using Python: {PYTHON}", flush=True)

    # ── 1. Start Flask backend ─────────────────────────────────────────────
    print(f"{tag('LAUNCHER', YELLOW)} Starting Flask backend on port {FLASK_PORT}...", flush=True)


    flask_proc = subprocess.Popen(
        [PYTHON, FLASK_SCRIPT],
        cwd=BASE_DIR,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    procs.append(flask_proc)

    # Give Flask 3 seconds to boot
    time.sleep(3)

    # Check if Flask died immediately
    if flask_proc.poll() is not None:
        # Read stderr to show the error
        err = flask_proc.stderr.read().decode('utf-8', errors='replace')
        print(f"{tag('FLASK', RED)} Failed to start! Error:", flush=True)
        for line in err.strip().splitlines()[-8:]:   # show last 8 lines
            print(f"{tag('FLASK', RED)} {line}", flush=True)
        print(f"\n{YELLOW}  ⚠️  Flask backend is down — AI prediction will not work.{RESET}")
        print(f"{YELLOW}     Fix: reinstall tensorflow in the correct Python env.{RESET}\n")
        # Do NOT exit — keep going with frontend only
    else:
        # Flask is alive — stream its output in background threads
        threading.Thread(target=stream_output, args=(flask_proc, 'FLASK', GREEN), daemon=True).start()
        threading.Thread(target=stream_stderr, args=(flask_proc, 'FLASK'), daemon=True).start()
        print(f"{tag('FLASK', GREEN)} Backend started OK!", flush=True)

    # ── 2. Start Frontend server ───────────────────────────────────────────
    print(f"{tag('LAUNCHER', YELLOW)} Starting Frontend server on port {FRONT_PORT}...", flush=True)

    front_proc = subprocess.Popen(
        [PYTHON, FRONT_SCRIPT],
        cwd=BASE_DIR,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    procs.append(front_proc)

    threading.Thread(target=stream_output, args=(front_proc, 'FRONTEND', CYAN),  daemon=True).start()
    threading.Thread(target=stream_stderr, args=(front_proc, 'FRONTEND'),         daemon=True).start()

    time.sleep(1)

    print(f"\n{BOLD}{GREEN}  Both servers started!{RESET}")
    print(f"{BOLD}  Open your browser: http://localhost:{FRONT_PORT}/auth.html{RESET}")
    print(f"{YELLOW}  Press Ctrl+C to stop everything.\n{RESET}")

    signal.signal(signal.SIGINT,  shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    # ── 3. Keep running — only exit if Frontend dies ───────────────────────
    while True:
        if front_proc.poll() is not None:
            print(f"{tag('LAUNCHER', RED)} Frontend server stopped unexpectedly. Shutting down.", flush=True)
            shutdown()
        time.sleep(1)

if __name__ == '__main__':
    run()
