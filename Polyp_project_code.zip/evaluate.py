"""
evaluate.py
===========
Comprehensive evaluation of the polyp detection model.

Generates:
  - Confusion matrix
  - Precision / Recall / F1-score (per image-level and per pixel-level)
  - ROC-AUC and Precision-Recall curve
  - False-positive analysis (which images are wrongly called 'polyp')
  - Per-class performance summary
  - Grad-CAM visualisations for false-positive images

Usage:
    python evaluate.py
    python evaluate.py --neg_dir CVC-612/negatives  (if you have negatives)
"""

import os
import sys
import argparse
import numpy as np
import cv2
import tensorflow as tf
from tensorflow.keras.utils import CustomObjectScope
from glob import glob
from tqdm import tqdm
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import (
    confusion_matrix, classification_report,
    roc_auc_score, average_precision_score,
    precision_recall_curve, roc_curve,
)
from data import load_data, load_negatives, read_image, read_mask
from train import iou, dice_coeff, dice_bce_loss

# ============================================================
# Configuration — mirror the values in app.py
# ============================================================
POLYP_AREA_THRESHOLD  = 2.0    # % pixels above 0.5 to consider polyp
POLYP_CONF_THRESHOLD  = 0.65   # mean sigmoid in detected region
UNKNOWN_CONF_THRESHOLD = 0.50  # below this → Unknown/Review

# ============================================================
# Argument parsing
# ============================================================
parser = argparse.ArgumentParser(description="Comprehensive Model Evaluation")
parser.add_argument("--neg_dir",    type=str, default="CVC-612/negatives",
                    help="Directory with hard-negative images (optional)")
parser.add_argument("--model_path", type=str, default="files/model.h5",
                    help="Path to trained model")
parser.add_argument("--out_dir",   type=str, default="files/evaluation",
                    help="Output directory for evaluation artefacts")
parser.add_argument("--save_gradcam", action="store_true",
                    help="Save Grad-CAM overlays for each false-positive")

# ============================================================
# Helpers
# ============================================================
def predict(model, image_arr):
    """Return (pred_mask H×W, mean_conf, area_pct, score)."""
    inp  = np.expand_dims(image_arr.astype(np.float32), axis=0)
    pred = model.predict(inp, verbose=0)[0].squeeze()
    activated = pred[pred > 0.5]
    mean_conf = float(np.mean(activated)) if len(activated) else 0.0
    area_pct  = float(np.mean(pred > 0.5)) * 100.0
    # Overall anomaly score = max probability across image
    score = float(np.max(pred))
    return pred, mean_conf, area_pct, score


def classify(mean_conf, area_pct):
    """Apply the same 4-class decision as app.py."""
    if area_pct >= POLYP_AREA_THRESHOLD and mean_conf >= POLYP_CONF_THRESHOLD:
        return "polyp"
    elif area_pct >= POLYP_AREA_THRESHOLD and mean_conf >= UNKNOWN_CONF_THRESHOLD:
        return "unknown"
    elif area_pct < 0.5:
        return "normal"
    else:
        return "non_polyp_lesion"


def compute_gradcam(model, image_arr, layer_name=None):
    """Compute Grad-CAM for the segmentation output."""
    if layer_name is None:
        for layer in reversed(model.layers):
            if len(layer.output.shape) == 4:
                layer_name = layer.name
                break

    grad_model = tf.keras.models.Model(
        inputs=model.input,
        outputs=[model.get_layer(layer_name).output, model.output],
    )
    inp = tf.cast(np.expand_dims(image_arr, 0), tf.float32)
    with tf.GradientTape() as tape:
        conv_out, predictions = grad_model(inp)
        loss = tf.reduce_mean(predictions)

    grads   = tape.gradient(loss, conv_out)
    weights = tf.reduce_mean(grads, axis=(0, 1, 2))
    cam     = tf.reduce_sum(weights * conv_out[0], axis=-1).numpy()
    cam     = np.maximum(cam, 0)
    cam    /= (cam.max() + 1e-8)
    return cv2.resize(cam, (256, 256))


def plot_confusion(cm, labels, save_path):
    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(cm, interpolation="nearest", cmap=plt.cm.Blues)
    plt.colorbar(im, ax=ax)
    ax.set(
        xticks=range(len(labels)), yticks=range(len(labels)),
        xticklabels=labels, yticklabels=labels,
        xlabel="Predicted", ylabel="True",
        title="Confusion Matrix",
    )
    thresh = cm.max() / 2.0
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, cm[i, j], ha="center", va="center",
                    color="white" if cm[i, j] > thresh else "black")
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()
    print(f"[Eval] Confusion matrix saved → {save_path}")


def plot_curves(y_true_bin, y_scores, save_path):
    """Plot ROC and PR curves."""
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    fig.suptitle("Model Evaluation Curves", fontsize=13, fontweight="bold")

    # ROC
    fpr, tpr, _ = roc_curve(y_true_bin, y_scores)
    auc = roc_auc_score(y_true_bin, y_scores)
    axes[0].plot(fpr, tpr, "b-", lw=2, label=f"ROC (AUC={auc:.3f})")
    axes[0].plot([0, 1], [0, 1], "k--", lw=1)
    axes[0].set(xlabel="False Positive Rate", ylabel="True Positive Rate",
                title="ROC Curve", xlim=(0, 1.02), ylim=(0, 1.02))
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)

    # Precision-Recall
    prec, rec, _ = precision_recall_curve(y_true_bin, y_scores)
    ap = average_precision_score(y_true_bin, y_scores)
    axes[1].plot(rec, prec, "r-", lw=2, label=f"PR (AP={ap:.3f})")
    axes[1].set(xlabel="Recall", ylabel="Precision",
                title="Precision–Recall Curve", xlim=(0, 1.02), ylim=(0, 1.02))
    axes[1].legend()
    axes[1].grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()
    print(f"[Eval] ROC/PR curves saved → {save_path}")


# ============================================================
# Main
# ============================================================
if __name__ == "__main__":
    args = parser.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)
    fp_dir = os.path.join(args.out_dir, "false_positives")
    os.makedirs(fp_dir, exist_ok=True)

    # ----------------------------------------------------------
    # Load model
    # ----------------------------------------------------------
    custom_objects = {"iou": iou, "dice_coeff": dice_coeff, "dice_bce_loss": dice_bce_loss}
    try:
        with CustomObjectScope(custom_objects):
            model = tf.keras.models.load_model(args.model_path)
        print(f"[Eval] Model loaded from {args.model_path}")
    except Exception as e:
        print(f"[ERROR] Could not load model: {e}")
        sys.exit(1)

    # ----------------------------------------------------------
    # Collect all evaluation images + ground truth labels
    # ----------------------------------------------------------
    eval_images  = []   # (path, gt_label_str)
    _, _, (test_x, test_y) = load_data("CVC-612/")

    for img_p, msk_p in zip(test_x, test_y):
        eval_images.append((img_p, msk_p, "polyp"))

    # Negatives
    if os.path.isdir(args.neg_dir):
        neg_paths = load_negatives(args.neg_dir)
        for p in neg_paths:
            if "mined" in p.lower():
                gt_label = "non_polyp_lesion"  # mined FPs are hard negatives
            else:
                gt_label = "non_polyp_lesion"
            eval_images.append((p, "", gt_label))

    # Images in project root (normal.jpeg, OIP.jpeg, etc.)
    for fname in ["normal.jpeg", "normal1.jpeg", "OIP.jpeg"]:
        fpath = os.path.join(os.path.dirname(__file__), fname)
        if os.path.exists(fpath):
            eval_images.append((fpath, "", "normal"))

    print(f"[Eval] Evaluating {len(eval_images)} images...")

    # ----------------------------------------------------------
    # Run inference
    # ----------------------------------------------------------
    y_true_str  = []
    y_pred_str  = []
    y_scores    = []   # anomaly score for ROC/PR (binary: polyp vs rest)
    fp_records  = []   # false-positive details

    for img_path, msk_path, gt_label in tqdm(eval_images, desc="Evaluating"):
        image_arr = read_image(img_path)
        pred_mask, mean_conf, area_pct, score = predict(model, image_arr)
        pred_label = classify(mean_conf, area_pct)

        y_true_str.append(gt_label)
        y_pred_str.append(pred_label)
        y_scores.append(score)

        # False positive: model says polyp, truth is not polyp
        if pred_label == "polyp" and gt_label != "polyp":
            fp_records.append({
                "path": img_path,
                "gt": gt_label,
                "pred": pred_label,
                "mean_conf": mean_conf,
                "area_pct": area_pct,
                "image_arr": image_arr,
                "pred_mask": pred_mask,
            })

    # ----------------------------------------------------------
    # Confusion matrix
    # ----------------------------------------------------------
    label_set = sorted(set(y_true_str + y_pred_str))
    cm = confusion_matrix(y_true_str, y_pred_str, labels=label_set)
    plot_confusion(cm, label_set, os.path.join(args.out_dir, "confusion_matrix.png"))

    # ----------------------------------------------------------
    # Classification report
    # ----------------------------------------------------------
    report = classification_report(y_true_str, y_pred_str, labels=label_set,
                                   zero_division=0)
    print("\n[Eval] Classification Report:")
    print(report)
    with open(os.path.join(args.out_dir, "classification_report.txt"), "w") as f:
        f.write(report)

    # ----------------------------------------------------------
    # ROC / PR curves (binary: polyp vs non-polyp)
    # ----------------------------------------------------------
    y_true_bin = [1 if lbl == "polyp" else 0 for lbl in y_true_str]
    if len(set(y_true_bin)) == 2:      # need both classes present
        try:
            plot_curves(y_true_bin, y_scores,
                        os.path.join(args.out_dir, "roc_pr_curves.png"))
        except Exception as e:
            print(f"[Eval] ROC/PR plot skipped: {e}")

    # ----------------------------------------------------------
    # False-positive analysis
    # ----------------------------------------------------------
    fp_count = len(fp_records)
    total_neg = sum(1 for lbl in y_true_str if lbl != "polyp")
    fpr = fp_count / (total_neg + 1e-9)

    print(f"\n[Eval] ===== FALSE-POSITIVE ANALYSIS =====")
    print(f"  Non-polyp images evaluated : {total_neg}")
    print(f"  Incorrectly called 'polyp' : {fp_count}")
    print(f"  False-Positive Rate        : {fpr*100:.1f}%")

    fp_report_lines = [
        "False Positive Analysis",
        "=" * 55,
        f"Non-polyp images evaluated : {total_neg}",
        f"Incorrectly called 'polyp' : {fp_count}",
        f"False-Positive Rate        : {fpr*100:.1f}%",
        "",
    ]

    for i, rec in enumerate(fp_records):
        line = (f"  [{i+1}] {os.path.basename(rec['path'])}"
                f"  GT={rec['gt']}  conf={rec['mean_conf']:.2f}"
                f"  area={rec['area_pct']:.1f}%")
        print(line)
        fp_report_lines.append(line)

        # Save Grad-CAM for FP
        if args.save_gradcam:
            cam = compute_gradcam(model, rec["image_arr"])
            orig_bgr = cv2.imread(rec["path"])
            if orig_bgr is not None:
                H, W = orig_bgr.shape[:2]
                cam_r  = cv2.resize(cam, (W, H))
                heatmap = cv2.applyColorMap(np.uint8(255 * cam_r), cv2.COLORMAP_JET)
                overlay = cv2.addWeighted(orig_bgr, 0.6, heatmap, 0.4, 0)

                # Annotate with attention note
                note = "Check: is model focusing on lesion or artifact?"
                cv2.putText(overlay, note, (4, 16), cv2.FONT_HERSHEY_SIMPLEX,
                            0.35, (255, 255, 0), 1, cv2.LINE_AA)

                vis_path = os.path.join(fp_dir,
                    f"fp_{i+1}_{os.path.basename(rec['path'])}_gradcam.png")
                cv2.imwrite(vis_path, overlay)

    with open(os.path.join(args.out_dir, "fp_analysis.txt"), "w") as f:
        f.write("\n".join(fp_report_lines))

    # ----------------------------------------------------------
    # Summary
    # ----------------------------------------------------------
    print(f"\n[Eval] ===== EVALUATION COMPLETE =====")
    print(f"  Output directory: {args.out_dir}")
    print(f"  Files generated:")
    print(f"    confusion_matrix.png")
    print(f"    classification_report.txt")
    print(f"    roc_pr_curves.png")
    print(f"    fp_analysis.txt")
    if args.save_gradcam and fp_records:
        print(f"    false_positives/*_gradcam.png  ({len(fp_records)} files)")
    print()
    if fp_count > 0:
        print(f"  ⚠  {fp_count} non-polyp image(s) were incorrectly classified as polyps.")
        print(f"     Run hard_negative_mining.py and retrain to reduce this number.")
    else:
        print(f"  ✓  Zero false-positive polyp detections on the evaluated set.")
